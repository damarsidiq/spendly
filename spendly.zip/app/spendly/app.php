<?php
/**
 *	Class App. Extension of the Pxpedia class
 *
 *	To hold additional functions required by your apps
 *		
 *	@name App
 **/
if(!class_exists('Pxpedia')){
	die();
}
Class App extends Pxpedia{
    function __construct(){
		parent::__construct();
    }
}



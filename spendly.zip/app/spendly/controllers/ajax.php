<?php
Class Ajax extends Controller{
    function __construct(){
        parent::__construct();
        date_default_timezone_set("Asia/Jakarta");
    }
    public function pdfreport($data){
        $repitems = explode(',',$this->model('blogattribute')->attribute($data['reportid'],'items'));
        $reportitems = $this->model('blog')->entries(5000000,0,array('id'=>array('IN',$repitems)), array('created','desc') );
        foreach($reportitems as $rk=>$rv){
            $reportitems[$rk]['amount'] = $this->model('blogattribute')->attribute($rv['id'],'amount');
        }
        $total = 0;
        foreach($reportitems as $k=>$v){
            if(strpos($reportitems[$k]['content'],'<body>') !== false){
                $contentx = explode('<body>',$reportitems[$k]['content']);
                $contentx = explode('</body>',$contentx[1]);
                $reportitems[$k]['content'] = $contentx[0];
            }
            $reportitems[$k]['created'] = date('l, F jS Y H:i:s',strtotime($v['created']));
            $reportitems[$k]['datecreated'] = date('Y-m-d',strtotime($v['created']));
            $reportitems[$k]['histime'] = explode(' ',$reportitems[$k]['created'])[4];
            $reportitems[$k]['amount'] = $this->model('blogattribute')->attribute($v['id'],'amount');
            $total += $reportitems[$k]['amount'];
            $reportitems[$k]['amountformatted'] = number_format($reportitems[$k]['amount']);
        }
        $repcont = '<h3>'. $this->model('blog')->getrecord(array('id'=>$data['reportid']),'title') .'</h3><p>'. $this->model('blog')->content($data['reportid']) .'</p>';
        $dateshow = false;
        for($i=0;$i<count($reportitems);$i++){
            if($dateshow==false){
                $dateshow = $reportitems[$i]['datecreated'];
                $reportitems[$i]['created'] = '<b>'.$reportitems[$i]['created'].'</b>';
            }
            else{
                if($dateshow == $reportitems[$i]['datecreated']){
                    $reportitems[$i]['created'] = $reportitems[$i]['histime'];
                }
                else{
                    $dateshow = $reportitems[$i]['datecreated'];
                    $reportitems[$i]['created'] = '<b>'.$reportitems[$i]['created'].'</b>';
                }
            }
            $repcont .= '<div><b>'.($i+1).'.  '.$reportitems[$i]['title'].'</b><span class="tbrtime">'.$reportitems[$i]['created'].'</span><br/>'.$reportitems[$i]['amountformatted'].'<br/><br/>'.$reportitems[$i]['content'].'<span class="outsepar"></span></div>';
        }
        $repcont .= '<div class="total">'.number_format($total).'</div>';
        
        $this->preppdffolder();
        $pdf = @scandir(App::getConfig('uploads').'pdfreport');
        $pdfid = count($pdf).'.txt';
        
        $handler = @fopen(App::getConfig('uploads').'pdfreport/'.$pdfid.'.txt','wb');
        fputs($handler,$repcont);
        
        $response['pdfid']= $pdfid;
        $this->setPagevar('response',$response);
        return 'ajax';
    }
    public function gen_tbr($data){
        $sdate = $data['startdate'];
        $edate = $data['enddate'];
        $total = 0;
        
        switch ($data['reptype']) {
            case 'Outlay':
                    $response['tbr_content'] = $this->model('blog')->query('select * from '.$this->model('blog')->table.' where id not in(select blogid from '.$this->model('blogattribute')->table.' where attrkey="archive") and category not in(8,9,10,11,14) and created >= "'. $sdate .'" and created <= "'. $edate .'" order by created desc');
                    $response['tbr_content'] = $this->model('blog')->fetchQueryResult($response['tbr_content']);
                    
                    foreach($response['tbr_content'] as $k=>$v){
                        if(strpos($response['tbr_content'][$k]['content'],'<body>') !== false){
                            $contentx = explode('<body>',$response['tbr_content'][$k]['content']);
                            $contentx = explode('</body>',$contentx[1]);
                            $response['tbr_content'][$k]['content'] = $contentx[0];
                        }
                        $response['tbr_content'][$k]['created'] = date('l, F jS Y H:i:s',strtotime($v['created']));
                        $response['tbr_content'][$k]['datecreated'] = date('Y-m-d',strtotime($v['created']));
                        $response['tbr_content'][$k]['histime'] = explode(' ',$response['tbr_content'][$k]['created'])[4];
                        $response['tbr_content'][$k]['amount'] = $this->model('blogattribute')->attribute($v['id'],'amount');
                        $total += $response['tbr_content'][$k]['amount'];
                        $response['tbr_content'][$k]['amountformatted'] = number_format($response['tbr_content'][$k]['amount']);
                    }
                    $response['total'] = $total;
            break;
            case 'Wishlist':
                    $response['tbr_content'] = $this->model('blog')->query('select * from '.$this->model('blog')->table.' where category =8 and id not in(select blogid from '.$this->model('blogattribute')->table.' where attrkey="archive")');
                    $response['tbr_content'] = $this->model('blog')->fetchQueryResult($response['tbr_content']);
                    
                    foreach($response['tbr_content'] as $k=>$v){
                        if(strpos($response['tbr_content'][$k]['content'],'<body>') !== false){
                            $contentx = explode('<body>',$response['tbr_content'][$k]['content']);
                            $contentx = explode('</body>',$contentx[1]);
                            $response['tbr_content'][$k]['content'] = $contentx[0];
                        }
                        $response['tbr_content'][$k]['created'] = date('l, F jS Y H:i:s',strtotime($v['created']));
                        $response['tbr_content'][$k]['datecreated'] = date('Y-m-d',strtotime($v['created']));
                        $response['tbr_content'][$k]['histime'] = explode(' ',$response['tbr_content'][$k]['created'])[4];
                        $response['tbr_content'][$k]['amount'] = $this->model('blogattribute')->attribute($v['id'],'amount');
                        $total += $response['tbr_content'][$k]['amount'];
                        $response['tbr_content'][$k]['amountformatted'] = number_format($response['tbr_content'][$k]['amount']);
                    }
                    $response['total'] = $total;
                    
                    $budgettotalobj = $this->model('blog')->entries(1,0,array('category'=>array('=',10)) , array('created','desc'));
                    foreach($budgettotalobj as $k=>$v){
                        $budgettotal = $this->model('blogattribute')->attribute($v['id'],'amount');
                    }
                    $response['budgetis'] = $budgettotal;
            break;
            case 'Income':
                $response['tbr_content'] = $this->model('blog')->query('select * from '.$this->model('blog')->table.' where category =9 and created >= "'. $sdate .'" and created <= "'. $edate .'" order by created desc');
                $response['tbr_content'] = $this->model('blog')->fetchQueryResult($response['tbr_content']);
                
                foreach($response['tbr_content'] as $k=>$v){
                    if(strpos($response['tbr_content'][$k]['content'],'<body>') !== false){
                        $contentx = explode('<body>',$response['tbr_content'][$k]['content']);
                        $contentx = explode('</body>',$contentx[1]);
                        $response['tbr_content'][$k]['content'] = $contentx[0];
                    }
                    $response['tbr_content'][$k]['created'] = date('l, F jS Y H:i:s',strtotime($v['created']));
                    $response['tbr_content'][$k]['datecreated'] = date('Y-m-d',strtotime($v['created']));
                    $response['tbr_content'][$k]['histime'] = explode(' ',$response['tbr_content'][$k]['created'])[4];
                    $response['tbr_content'][$k]['amount'] = $this->model('blogattribute')->attribute($v['id'],'amount');
                    $total += $response['tbr_content'][$k]['amount'];
                    $response['tbr_content'][$k]['amountformatted'] = number_format($response['tbr_content'][$k]['amount']);
                }
                $response['total'] = $total;
            break;
            default:
                $cat = explode('_',$data['reptype'])[1];
                $response['tbr_content'] = $this->model('blog')->query('select * from '.$this->model('blog')->table.' where category='. $cat .' and id not in(select blogid from '.$this->model('blogattribute')->table.' where attrkey="archive") and created >= "'. $sdate .'" and created <= "'. $edate .'" order by created desc');
                $response['tbr_content'] = $this->model('blog')->fetchQueryResult($response['tbr_content']);
                
                foreach($response['tbr_content'] as $k=>$v){
                    if(strpos($response['tbr_content'][$k]['content'],'<body>') !== false){
                        $contentx = explode('<body>',$response['tbr_content'][$k]['content']);
                        $contentx = explode('</body>',$contentx[1]);
                        $response['tbr_content'][$k]['content'] = $contentx[0];
                    }
                    $response['tbr_content'][$k]['created'] = date('l, F jS Y H:i:s',strtotime($v['created']));
                    $response['tbr_content'][$k]['datecreated'] = date('Y-m-d',strtotime($v['created']));
                    $response['tbr_content'][$k]['histime'] = explode(' ',$response['tbr_content'][$k]['created'])[4];
                    $response['tbr_content'][$k]['amount'] = $this->model('blogattribute')->attribute($v['id'],'amount');
                    $total += $response['tbr_content'][$k]['amount'];
                    $response['tbr_content'][$k]['amountformatted'] = number_format($response['tbr_content'][$k]['amount']);
                }
                $response['total'] = $total;
            break;
        }
        
        $this->setPagevar('response',$response);
        
        return 'ajax';
    }
    public function tbr_pdf($data){
        $this->preppdffolder();
        $pdf = @scandir(App::getConfig('uploads').'pdfreport');
        $pdfid = count($pdf).'.txt';
        
        $handler = @fopen(App::getConfig('uploads').'pdfreport/'.$pdfid.'.txt','wb');
        fputs($handler,$data['content']);
        
        $response['pdfid']= $pdfid;
        $this->setPagevar('response',$response);
        return 'ajax';
    }
    public function timebasedrep($pdfid){
        $repcontent = file_get_contents(App::getConfig('uploads').'pdfreport/'.$pdfid.'.txt');
        
        return $repcontent;
    }
    public function downloadpdf($data){
        $this->model('blogpdf')->pdfcontent = $this->timebasedrep($data['pdfid']);
        
        $this->model('blogpdf')->outputdompdf();
    }
    public function preppdffolder(){
        if(!file_exists(App::getConfig('uploads').'pdfreport')){
            $dir = mkdir(App::getConfig('uploads').'pdfreport',0777);
            if(!$dir){
                return false;
            }
        }
        return true;
    }
}
?>
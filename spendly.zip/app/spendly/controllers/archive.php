<?php 
Class Archive extends Controller{
	function __construct(){
		parent::__construct();
	}
	
	public function cleanarchive($data){
	    $q2 = 'select blogid from blogattribute where attrkey = "archive"';
	    
	    $archids = $this->query($q2);
	    $archidsx = $this->fetchQueryResults($archids);
	    $xx = '';
	    foreach($archidsx as $k=>$v){
	        $xx .= $v['blogid'].',';
	    }
	    $archidsxx = substr($xx,0,-1);
	    
	    $q = 'delete from blog where id in ('.$archidsxx.')';
	    $qs = $this->query($q);
	    
	    echo print_r($qs,true);
	    echo '<br/><br/><br/>';
	    
	    $q3 = 'delete from blogattribute where blogid in('.$archidsxx.')';
	    $qs2 = $this->query($q3);
	    
	    
	   echo print_r($qs2,true);
	   
	   return 'plain';
	}
}

<?php

Class Home extends Controller{
    function __construct() {
        parent::__construct();
        date_default_timezone_set("Asia/Jakarta");
    }
    
    public function pageInit($data,$view='home'){
        App::loginuser(1);
        $latestspending = $this->model('blog')->fetchQueryResult($this->model('blog')->query('select * from '.$this->model('blog')->table.' where category not in(8,9,10,11,14) and status = 1 and id not in(select blogid from '.$this->model('blogattribute')->table.' where attrkey="archive") order by created desc limit 0,20'));
        foreach($latestspending as $k=>$v){
            $latestspending[$k]['amount'] = $this->model('blogattribute')->attribute($v['id'],'amount');
        }
        
        $qs = $this->model('blog')->query('select * from '.$this->model('blog')->table.' where id not in(select blogid from '.$this->model('blogattribute')->table.' where attrkey="archive") and category = 8 and status = 1 order by id desc');
        
        $twishlist = $this->model('blog')->fetchQueryResult($qs);
        $wishlist = array(count($twishlist));
        $overrideorder = array(count($twishlist));
        $override = false;
        foreach($twishlist as $k=>$v){
            $twishlist[$k]['amount'] = $this->model('blogattribute')->attribute($v['id'],'amount');
            $order = $this->model('blogattribute')->getrecords(array('blogid'=>$v['id'],'attrkey'=>'order'),'value',array('id','desc'));
            if(!count($order) || $override)
            {
                $override = true;
                $twishlist[$k]['order'] = $k;
            }
            else{
                $order = $order[0]['value'];
                $twishlist[$k]['order'] = $order;
                $wishlist[intval($order)] = $twishlist[$k];
            }
            $overrideorder[$k] = $twishlist[$k];
        }
        if($override){
            $wishlist = $overrideorder;
        }
        else
            ksort($wishlist);
        
        $pastreports = $this->model('blog')->entries(10000,0,array('category'=>array('=',11)) , array('created','desc') );
        foreach($pastreports as $k=>$v){
            $pastreports[$k]['amount'] = $this->model('blogattribute')->attribute($v['id'],'amount');
        }
        
        $budgetlist = $this->model('blog')->entries(10,0,array('category'=>array('=',9)) , array('created','desc'));
        foreach($budgetlist as $k=>$v){
            $budgetlist[$k]['amount'] = ($this->model('blogattribute')->attribute($v['id'],'amount'));
        }
        
        $budgettotalobj = $this->model('blog')->entries(1,0,array('category'=>array('=',10)) , array('created','desc'));
        if(!count($budgettotalobj)){
            $budgetitemdata =array('category'=>10,'title'=>'budgettotal','status'=>1);
            $budgetitem = $this->model('blog')->addblog($budgetitemdata);
            $this->model('blogattribute')->addattr($budgetitem,'amount',0);
            
            $budgettotalobj = $this->model('blog')->entries(1,0,array('category'=>array('=',10)) , array('created','desc'));
        }
        foreach($budgettotalobj as $k=>$v){
            $budgettotal = $this->model('blogattribute')->attribute($v['id'],'amount');
        }
        
		list($blogcat,$blogparenthierarchy) 	= $this->model('blogcategories')->categories();
        $this->setPagevar('categories',$blogparenthierarchy);
        
        $this->setPagevar('latestspending',$latestspending);
        $this->setPagevar('wishlist',$wishlist);
        $this->setPagevar('pastreports',$pastreports);
        $this->setPagevar('budgetlist',$budgetlist);
        $this->setPagevar('budgettotal',$budgettotal);
        
        if(App::isMobile()){
             $this->addheadfootsrc(false,array('mobile'=>App::getConfig('appviews').'/styles/mobile.css'));
             $this->setPagevar('ismobile','true');
        }
        else{
            $this->setPagevar('ismobile','false');
        }
    }
}
<?php

Class Outlay extends Controller{
    function __construct() {
        parent::__construct();
        date_default_timezone_set("Asia/Jakarta");
    }
    public function sortwish($data){
        $wishids = explode('|',$data['order']);
        foreach($wishids as $wk=>$wid){
            $this->model('blogattribute')->addattr($wid,'order',$wk);
        }
        return 'plain';
    }
    public function thereport($data){
        $repitems = explode(',',$this->model('blogattribute')->attribute($data['id'],'items'));
        $reportitems = $this->model('blog')->entries(5000000,0,array('id'=>array('IN',$repitems)), array('created','desc') );
        foreach($reportitems as $rk=>$rv){
            $reportitems[$rk]['amount'] = $this->model('blogattribute')->attribute($rv['id'],'amount');
        }
        
        $this->setPagevar('response',$reportitems);
        return 'ajax';
    }
    public function savereport($data){
        $amount = $data['amount'];
        $repitems = $data['items'];
        $repid = $data['id'];
        
        unset($data['amount']);
        unset($data['items']);
        unset($data['id']);
        $data['category'] = 11;
        
        if($data['content'] == 'Description'){
            $data['content'] = '';
        }
        $data['created'] = date('Y-m-d H:i:s',time());
        $data['modified'] = date('Y-m-d H:i:s',time());
        $data['excerpt'] = '';
        
        if($repid == 'false'){
            $data['status'] = 1;
            $blogid = $this->model('blog')->addblog($data);
            $this->model('blogattribute')->addattr($blogid,'amount',$amount);
            $this->model('blogattribute')->addattr($blogid,'items',$repitems);            
        }
        else{
            $blogid = $repid;
            $this->model('blog')->updaterecord($data,array('id'=>$repid));
            $this->model('blogattribute')->updaterecord(array('value'=>$amount),array('blogid'=>$blogid,'attrkey'=>'amount'));
            $this->model('blogattribute')->updaterecord(array('value'=>$repitems),array('blogid'=>$blogid,'attrkey'=>'items'));
        }
        $response['result'] = $blogid;
        $response['created'] = date('Y-m-d',time());
        
        $this->setPagevar('response',$response);
        return 'ajax';
    }
    public function updatewish($data){
        $data['status'] = 1;
        $wishid = $data['wishid'];
        unset($data['wishid']);
        $amount = $data['amount'];
        unset($data['amount']);
        
            $this->flagasarchive($wishid);
            $data['category'] = 8;
            $cattobe = $this->model('blogattribute')->attribute($wishid,'categorytobe');
            if($data['content'] == 'Description'){
                $data['content'] = '';
            }
            $data['created'] = date('Y-m-d H:i:s',time());
            $data['modified'] = date('Y-m-d H:i:s',time());
            $data['excerpt'] = '';
            $response['result'] = $this->model('blog')->addblog($data);
            if($response['result']!=false){
                $this->model('blogattribute')->addattr($response['result'],'amount',$amount);
                $this->model('blogattribute')->addattr($response['result'],'categorytobe',$cattobe);
                $this->controller('rareity')->postactivity($data,$amount);
            }
            else{
                $response['debug'] = $this->model('blog')->printerrors(false);
            }   
        

        $this->setPagevar('response',$response);
        
        return 'ajax';
    }
    public function filteredoutlay($data){
        if($data['type'] == 'day'){
            $qs = 'select * from '.$this->model('blog')->table.' where status = 1 and created like "%'.$data['value'].'%" and category not in(8,9,10,11,14) and id not in(select blogid from '.$this->model('blogattribute')->table.' where attrkey="archive") order by created desc limit '.$data['offset'].',50000';
            $latestspending = $this->model('blog')->fetchQueryResult($this->model('blog')->query($qs));
        }
        else{
            $filter = explode(' ',$data['value']);
            $dayfilter = $filter[0];
            $catfilter = $filter[1];
            
            $qs = 'select * from '.$this->model('blog')->table.' where status = 1 and created like "%'.$dayfilter.'%" and category='.$catfilter.' and id not in(select blogid from '.$this->model('blogattribute')->table.' where attrkey="archive") order by created desc limit '.$data['offset'].',50000';
            $latestspending = $this->model('blog')->fetchQueryResult($this->model('blog')->query($qs));
        }
            
        foreach($latestspending as $k=>$v){
            $latestspending[$k]['amount'] = number_format($this->model('blogattribute')->attribute($v['id'],'amount'));
        }
        
        $this->setPagevar('response',$latestspending);
        return 'ajax';
    }
    public function outlaydesc($data){
        $response['content'] = $this->model('blog')->content($data['outlayid']);
        $response['created'] = $this->model('blog')->getrecord(array('id'=>$data['outlayid']),'created');
        
                
        $this->setPagevar('response',$response);
        return 'ajax';
    }
    public function oldbudget($data){
        $budgetlist = $this->model('blog')->entries(10,$data['offset'],array('category'=>array('=',9)),array('created','desc'));
        
        foreach($budgetlist as $k=>$v){
            $budgetlist[$k]['amount'] = number_format($this->model('blogattribute')->attribute($v['id'],'amount'));
        }
        
        $this->setPagevar('response',$budgetlist);
        return 'ajax';
    }
    public function oldoutlay($data){
        if($data['filter'] != 'false'){
            if($data['filter'][0]=='#'){
                $data['oldies']=true;
                $data['keyword']=$data['filter'];
                $latestspending = $this->searchoutlay($data);
            }
            elseif($data['filter'][0]=='~'){
                $data['oldies']=true;
                $data['keyword']=$data['filter'];
                $latestspending = $this->searchbudget($data);
            }
            else{
                $qs = 'select * from '.$this->model('blog')->table.' where status = 1 and category='.$data['filter'].' and id not in(select blogid from '.$this->model('blogattribute')->table.' where attrkey="archive") order by created desc limit '.$data['offset'].',10';
                $latestspending = $this->model('blog')->fetchQueryResult($this->model('blog')->query($qs));
            }
        }
        else{
            $qs = 'select * from '.$this->model('blog')->table.' where status = 1 and category not in(8,9,10,11,14) and id not in(select blogid from '.$this->model('blogattribute')->table.' where attrkey="archive") order by created desc limit '.$data['offset'].',10';
            $latestspending = $this->model('blog')->fetchQueryResult($this->model('blog')->query($qs));
        }
        
        foreach($latestspending as $k=>$v){
            $latestspending[$k]['amount'] = number_format($this->model('blogattribute')->attribute($v['id'],'amount'));
        }
        
        $this->setPagevar('response',$latestspending);
        return 'ajax';
    }
    public function searchbudget($data){
        $data['keyword'] = explode('~',$data['keyword']);
        
        $likeness = '(';
        foreach($data['keyword'] as $k=>$v){
            if($k==0){
                continue;
            }
            if($k>1){
                $likeness .= ' or ';
            }
            $likeness .= 'content like "%'.$v.'%" or title like "%'.$v.'%"';
        }
        $likeness .= ')';
        
        
        $qs = 'select * from '.$this->model('blog')->table.' where status = 1 and category =9 and '.$likeness.' order by created desc limit '.$data['offset'].',10';
        
        $latestspending = $this->model('blog')->fetchQueryResult($this->model('blog')->query($qs));
        
        if(isset($data['oldies'])){
            return $latestspending;
        }
        
        foreach($latestspending as $k=>$v){
            $latestspending[$k]['amount'] = number_format($this->model('blogattribute')->attribute($v['id'],'amount'));
        }
        $response['result'] = $latestspending;
        $this->setPagevar('response',$response);
        return 'ajax';
    }
    public function searchoutlay($data){
        $data['keyword'] = explode('#',$data['keyword']);
        
        $likeness = '(';
        foreach($data['keyword'] as $k=>$v){
            if($k==0){
                continue;
            }
            if($k>1){
                $likeness .= ' or ';
            }
            $likeness .= 'content like "%'.$v.'%" or title like "%'.$v.'%"';
        }
        $likeness .= ')';
        
        
        $qs = 'select * from '.$this->model('blog')->table.' where status = 1 and category not in(8,9,10,11,14) and id not in(select blogid from '.$this->model('blogattribute')->table.' where attrkey="archive") and '.$likeness.' order by created desc limit '.$data['offset'].',10';
        
        $latestspending = $this->model('blog')->fetchQueryResult($this->model('blog')->query($qs));
        
        if(isset($data['oldies'])){
            return $latestspending;
        }
        
        foreach($latestspending as $k=>$v){
            $latestspending[$k]['amount'] = number_format($this->model('blogattribute')->attribute($v['id'],'amount'));
        }
        $response['result'] = $latestspending;
        $this->setPagevar('response',$response);
        return 'ajax';
    }
    public function deletewish($data){
        $wi = $this->model('blog')->getrecord(array('id'=>$data['wishid']));
        $response = $this->flagasarchive($data['wishid']);
        
        $this->setPagevar('response',$response);
        return 'ajax';
    }
    public function archiverecord($data){
        $archid = $data['id'];
        unset($data['id']);
        $data['category'] = 14;
        return $this->model('blog')->updaterecord($data,array('id'=>$archid));
    }
    public function addbudget($data,$view='ajax'){
        $amount = $data['amount'];
        unset($data['amount']);
        $data['category'] = 9;
        
        if($data['content'] == 'Description'){
            $data['content'] = '';
        }
        $data['excerpt'] = '';
        $data['created'] = date('Y-m-d H:i:s',time());
        $data['modified'] = date('Y-m-d H:i:s',time());
        $data['status'] = 1;
        $blogid = $this->model('blog')->addblog($data);
        if($blogid != false){
            $this->model('blogattribute')->addattr($blogid,'amount',$amount);
        
            $response['result'] = $blogid;
            $response['created'] = date('Y-m-d',time());
            $budgettotalobj = $this->model('blog')->entries(1,0,array('category'=>array('=',10)),array('id','desc'));
            foreach($budgettotalobj as $k=>$v){
                $budgettotal = $this->model('blogattribute')->attribute($v['id'],'amount');
                $budgettotal += $amount;
                $this->updatebudget($budgettotal,$blogid);
            }   
        }
        else{
            $this->model('blogattribute')->addattr($blogid,'amount',$amount);
        
            $response['result'] = false;
        }
        $this->setPagevar('response',$response);
        return 'ajax';
    }
    public function newwish($data,$view='ajax'){
        $amount = $data['amount'];
        $categorytobe = $data['category'];
        unset($data['amount']);
        $data['category'] = 8;
        
        if($data['content'] == 'Description'){
            $data['content'] = '';
        }
        $data['created'] = date('Y-m-d H:i:s',time());
        $data['modified'] = date('Y-m-d H:i:s',time());
        $data['excerpt'] = '';
        $data['status'] = 1;
        $blogid = $this->model('blog')->addblog($data);
        if($blogid!=false){
            $this->model('blogattribute')->addattr($blogid,'amount',$amount);
            $this->model('blogattribute')->addattr($blogid,'categorytobe',$categorytobe);   
            $this->controller('rareity')->postactivity($data,$amount);
        }
        $response['result'] = $blogid;
        $this->setPagevar('response',$response);
        return 'ajax';
    }
    public function addnew($data,$view='ajax'){
        $amount = $data['amount'];
        unset($data['amount']);
        
        if($data['content'] == 'Description'){
            $data['content'] = '';
        }
        $data['created'] = date('Y-m-d H:i:s',time());
        $data['modified'] = date('Y-m-d H:i:s',time());
        $data['excerpt'] = '';
        $data['status'] = 1;
        
        $blogid = $this->model('blog')->addblog($data);
        if($blogid !=false){
            $this->model('blogattribute')->addattr($blogid,'amount',$amount);
            $this->controller('rareity')->postactivity($data,$amount);
            
            $budgettotalobj = $this->model('blog')->entries(1,0,array('category'=>array('=',10)));
            foreach($budgettotalobj as $k=>$v){
                $budgettotal = $this->model('blogattribute')->attribute($v['id'],'amount');
                $budgettotal -= $amount;
                $this->updatebudget($budgettotal,$blogid);
            }   
        }
            $response['result'] = $blogid;
            $response['created'] = date('Y-m-d',time());
            $response['amount'] = number_format($amount);
        
        $this->setPagevar('response',$response);
        return 'ajax';
    }
    public function confirmwish($data){
        $categorytobe = $this->model('blogattribute')->attribute($data['wishid'],'categorytobe');

        $wishid = $data['wishid'];
        $amount = $data['amount'];
        unset($data['wishid']);
        unset($data['amount']);
        
        if($data['content'] == 'Description'){
            $data['content'] = '';
        }
        $data['excerpt'] = '';
        
       
            $this->flagasarchive($wishid);
            
            $resp['result'] = true;
            $data['created'] = date('Y-m-d H:i:s',time());
            $data['modified'] = date('Y-m-d H:i:s',time());
            $data['category'] = $categorytobe;
            $data['status'] = 1;
            
            $blogid = $this->model('blog')->addblog($data);
            if($blogid!=false){
                $this->controller('rareity')->postactivity($data,$amount);
                $this->model('blogattribute')->addattr($blogid,'amount',$amount);
            
                $budgettotalobj = $this->model('blog')->entries(1,0,array('category'=>array('=',10)),array('id','desc'));
                foreach($budgettotalobj as $k=>$v){
                    $budgettotal = $this->model('blogattribute')->attribute($v['id'],'amount');
                    $budgettotal -= $amount;
                    
                    $this->updatebudget($budgettotal,$blogid);
                }
            }
        
        $resp['created'] = date('Y-m-d',time());
        $this->setPagevar('response',$resp);
        
        return 'ajax';
    }
    public function flagasarchive($blogid){
        return $this->model('blogattribute')->addrecord(array('blogid','attrkey','value'),array($blogid,'archive','true'));
    }
    public function updatebudget($budgettotal,$modifier=false){
        $data = array('content'=>'');
        $data['excerpt'] = '';
        $data['title'] = 'budgettotal';
        $data['status'] = 1;
        $data['created'] = date('Y-m-d H:i:s',time());
        $data['modified'] = date('Y-m-d H:i:s',time());
        $data['category'] = 10;
        
        $blogid = $this->model('blog')->addblog($data);
        $this->model('blogattribute')->addattr($blogid,'amount',$budgettotal);
        
        if($modifier!=false){
            $this->model('blogattribute')->addattr($blogid,'budget_modifier',$modifier);
        }
        return $blogid;
    }
}
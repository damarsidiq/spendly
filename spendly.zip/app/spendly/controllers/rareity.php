<?php 
Class Rareity extends Controller{
    var $rareityexists;
	function __construct(){
		parent::__construct();
		$this->rareityexists = (count($this->model('activity')->db->errors) > 0 ? false : true );
		date_default_timezone_set("Asia/Jakarta");
	}
	public function postactivity($data,$amount){
	    if(!$this->rareityexists){
	        return;
	    }
	    
	    $rdata['name'] = $this->model('blogcategories')->getrecord(array('id'=>$data['category']),'name');
	    $rdata['description'] = date('ynjH').'. '.$data['title'].': '.$amount.'<br/>'. (strpos($data['content'],'<p><br data-mce-bogus="1"></p>') === false ? (trim(strip_tags($data['content'])) == '' ? '' : $data['content'])  : '');
	    $rdata['time'] = date('Y-m-d H:i:s',time());
	    $rdata['duration'] = 0;
	    $rdata['priority'] = 7;
	    $rdata['type'] = 2;
	    $rdata['recurringtype'] = 0;
	    $rdata['parentactivity'] = 0;
	    $rdata['cost'] = 0;
	    
	    
	    $posted = $this->model('activity')->postact($rdata);
	    return $posted;
	}
}

<?php 
Class Suggest extends Controller{
    var $suggeststarts;
    var $matched;
    var $daily;
	function __construct(){
		parent::__construct();
		$this->suggeststarts = [];
		$this->matched = [];
		$this->daily = 0;
	}
	
	public function parsedata($data){
	    $x = explode('^',explode('~',$data['keyword'])[1]);
	    $data['duration'] = $x[1];
	    $data['budget'] = floatval($x[0]);
	    $data['randomed'] = isset($x[2]) ? explode('@',$x[2]) : array();
	    
	    return $data;
	}
	public function getrandomstart($duration,$numrow){
	    if(function_exists('random_int'))
	        $randstart = random_int(0,($numrow-$duration));
	    else
	        $randstart = rand(0,($numrow-$duration));
	    
	    return $randstart;
	}
	public function consdays($duration,$budget,$numrow){
	    $this->daily++;
	    if($this->daily > 300){
	        return;
	    }
	    
	    $randerlim = 0;
	    $randstart = $this->getrandomstart($duration,$numrow);
	    while(in_array($randstart,$this->suggeststarts)){
	        $randstart = $this->getrandomstart($duration,$numrow);
	        $randerlim++;
	        if($randerlim > 2000)
	            break;
	    }
	    if(in_array($randstart,$this->suggeststarts)){
	        return;
	    }
	    $this->suggeststarts[] = $randstart;
	    
	    $consq = $this->query('SELECT SUM(ba.value) AS dailyspending,count(*) as itemcount,b.id,b.category,b.created FROM `blog` as b,blogattribute as ba where b.status = 1 and b.category not in(8,9,10,11,14) and b.id not in(select blogid from blogattribute where attrkey="archive") and  ba.blogid = b.id and ba.attrkey = "amount" group by DATE_FORMAT(b.created,"%Y-%m-%d") order by b.created asc limit '.$this->suggeststarts[count($this->suggeststarts)-1].','.$duration);
	    $cons = $this->fetchQueryResult($consq);
	    
	    $total = 0;
	    $itemcount = 0;
	    foreach($cons as $l=>$lv){
	        $total+=$lv['dailyspending'];
	        $itemcount+=$lv['itemcount'];
	    }
	    if($total>$budget){
	        return $this->consdays($duration,$budget,$numrow);
	    }
	    else{
	        $idx = count($this->matched);
	        $this->matched[$idx]['total'] = $total;
	        $this->matched[$idx]['itemcount'] = $itemcount;
	        $this->matched[$idx]['suggeststarts'] = (count($this->suggeststarts)-1);
	        $this->matched[$idx]['start'] = explode(' ',$cons[0]['created'])[0];
	        
	        
	        if(count($this->matched)==3){
	            return;
	        }
	        else{
	            return $this->consdays($duration,$budget,$numrow);
	        }
	    }
	}
	public function cleanelse(){
	    foreach($this->matched as $k=>$v){
	        if($k==0)
	            continue;
	            
	       array_splice($this->suggeststarts,$v['suggeststarts'],1);
	    }
	}
	public function spendsuggestion($data){
	    $data = $this->parsedata($data);
	    if(count($data['randomed'])>0){
	        $this->suggeststarts = $data['randomed'];
	    }
	    
	    $c = $this->fetchQueryResult($this->query('select count(*) as numrow from (SELECT b.id FROM `blog` as b where b.status = 1 and b.category not in(8,9,10,11,14) and b.id not in(select blogid from blogattribute where attrkey="archive") group by DATE_FORMAT(b.created,"%Y-%m-%d")) as a'))[0]['numrow'];
	    
	    $this->consdays($data['duration'],$data['budget'],$c);
	    
	    if(count($this->matched) ==0){
	        $response['result'] = array();
    	    $this->setPagevar('response',$response);
    	    return 'ajax';
	    }
	    $sorted = array();
	    foreach($this->matched as $mk=>$mv){
	        if($mk==0){
	            $sorted[$mk] = $mv;
	        }
	        else{
	            if($sorted[0]['total'] < $mv['total']){
	                array_unshift($sorted,$mv);
	            }
	            else{
	                $sorted[] = $mv;
	            }
	        }
	    }
	    $this->matched = $sorted;
	    $this->cleanelse();
	    
	    $response['startscons'] = implode('@',$this->suggeststarts);
	    $listq = $this->query('SELECT ba.value,b.id,b.title,b.category,b.created,b.content FROM `blog` as b,blogattribute as ba where b.status = 1 and b.created >= "'.$this->matched[0]['start'].'" and b.category not in(8,9,10,11,14) and b.id not in(select blogid from blogattribute where attrkey="archive") and ba.blogid = b.id order by b.created limit '.$this->matched[0]['itemcount']);
	    $list= $this->fetchQueryResult($listq);
	    
	    foreach($list as $k=>$v){
            $list[$k]['amount'] = number_format($v['value']);
        }
	    
	    $response['result'] = $list;
	    
	    $this->setPagevar('response',$response);
	    return 'ajax';
	}
}

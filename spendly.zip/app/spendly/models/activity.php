<?php 
Class Activity extends Model{
    function __construct(){
        parent::__construct('activity',App::getappid('rareity'));
    }
    
    public function postact($data){
        foreach($data as $k=>$v){
           if($k=='description' && $v=='description'){
                $v = '';
            }
            $keys[] = $k;
            $vals[] = $v;
        }
	    $res = $this->addrecord($keys,$vals);
	    return $res;
    }
}
?>

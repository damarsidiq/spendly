<?php
/**
 * BlogAttribute model class.
 */

/**
 *	Class BlogAttribute. class for BlogAttribute table manipulation
 *	@name BlogAttribute
 *	@author Erwanto Damarsidiq <damarsidiq@gmail.com>
 *	@license http://www.opensource.org/licenses/mit-license.php MIT
 *
 **/
Class BlogAttribute extends Model{
    /**
	 * Constructor. 
	 */
    function __construct(){
        parent::__construct('blogattribute');
    }
    /**
	 * attribute. get blog entry attribute
	 *
	 * @param int $blogid the blog ID
	 * @param string $attrkey the blog attribute name
	 * 
	 * @return array
	 */
    public function attribute($blogid,$attrkey=false){
        if($attrkey === false)
            return $this->getrecord(array('blogid'=>$blogid),'value');
        
        return $this->getrecord(array('blogid'=>$blogid,'attrkey'=>$attrkey),'value');
    }
    /**
	 * blogattributes. get blog entry attributes
	 *
	 * @param int $blogid the blog ID
	 * 
	 * @return array
	 */
    public function blogattributes($blogid){
        $attributes = $this->getrecords(array('blogid'=>$blogid),array('attrkey','value'));
        
        return $attributes;
    }
    public function addattr($blogid,$key,$value){
        $this->addrecord(array('blogid','attrkey','value'),array($blogid,$key,$value));
    }
}


?>
<?php 
Class Blogpdf extends Model{
    var $pdfheader;
    var $pdfcontent;
    
	function __construct(){
		parent::__construct();
		
        $this->pdfheader    = '<style type="text/css">
                    <!--
                        html{font-family:Arial;font-size:12px}
                        a{color:#949494;text-decoration: none;font-size: 34px;}
                        img{display: block;margin: auto;max-width: 100%;}
                        li{padding:0px;margin:5px 0px;}
                        .outsepar{border-top: 1px dotted #404040;width: 100%;height: 5px;padding:7px 0px;display:block;}
                        p{display: block;margin-bottom: 1em;margin-top: 1em;}
                        ul{padding:0px;margin:0px;}
                        #thebudget,.total{color: #404040;font-size: 50px;height: 50px;line-height: 50px;text-align: right;}
                        .total{padding-right: 1%;}
                        .tbrtime{display:inline-block;position:absolute;right:0px;color:#404040;line-height:12px;}
                        #tbr_content{width: 98%;padding: 0px 1%;font-size:12px;}
                        #tbr_content div{width: 98%;float: right;padding: 0px 1%;page-break-after:auto;position:relative}
                    -->
                    </style>';
        
        $this->undecoded = array('&apos;','&lt;','&gt;');
        $this->undecodedreplacement = array('','(',')');
        $this->pdfcontent = '';
	}
	public function cleanstr($str,$setlandscape=false){
         //return str_replace(array('<figcaption','figcaption>','<figure','figure>','<section','section>','<aside','aside>'),array('<p','p>','<p','p>','<div','div>','<div','div>'),htmlspecialchars_decode(str_replace($this->undecoded,$this->undecodedreplacement,$str),ENT_QUOTES));
         $cs = htmlspecialchars_decode(str_replace($this->undecoded,$this->undecodedreplacement,$str),ENT_QUOTES);

        if(strpos($cs,'<img') === false){
          return $cs;
        }
         $cs = explode('<img',$cs);


         $a4 = $setlandscape ? array('72'=>array(595,842),'96'=>array(794,1123),'150'=>array(1240,1754),'300'=>array(2480,3508)) : array('72'=>array(842,595),'96'=>array(1123,794),'150'=>array(1754,1240),'300'=>array(3508,2480));
         foreach ($cs as $l=>$value) {
             if($value =='')
                continue;


             if($l >0){
                 $i = explode('src="',$value);
                 $i = explode('"',$i[1])[0];


                 list($width,$height) = getimagesize($i);

                 $x = explode('>',$value);
                 $marginleft= $width<($a4['96'][1]-90) ? ((($a4['96'][1]-90)-$width)/2) : 0;
                 $width = $marginleft == 0 ? ($a4['96'][1]-90) : $width;
                 $height= min($height,($a4['96'][0]-90));
                 
                 
                 $x[0] = ' style="height:'.$height.'px;margin:auto;margin-left:'.$marginleft.'px;width:'.$width.'px;" '.$x[0];
                 $x[1] = '</div>'.$x[1];
                 $value = implode('>',$x);

                $cs[$l] = $value;

                $value = '<div style="page-break-before:auto;page-break-after:auto;clear:both;width:100%;text-align:center;height:'.$height.'px;">';
                $cs[$l-1] = $cs[$l-1].$value;
             }
         }
         $cs = implode('<img',$cs);
         return $cs;
    }
	 public function outputdompdf(){
        require_once Pxpedia::getConfig('resources').'dompdf/lib/html5lib/Parser.php';
        require_once Pxpedia::getConfig('resources').'dompdf/lib/php-font-lib/src/FontLib/Autoloader.php';
        require_once Pxpedia::getConfig('resources').'dompdf/lib/php-svg-lib/src/autoload.php';
        require_once Pxpedia::getConfig('resources').'dompdf/src/Autoloader.php';


        require_once Pxpedia::getConfig('resources').'dompdf/src/CanvasFactory.php';
        require_once Pxpedia::getConfig('resources').'dompdf/src/Options.php';
        require_once Pxpedia::getConfig('resources').'dompdf/src/Dompdf.php';
        Dompdf\Autoloader::register();

        $dompdf = new Dompdf\Dompdf();
        
        $this->pdfcontent = $this->cleanstr($this->pdfcontent);
        
        $dompdf->loadHtml($this->pdfheader.$this->pdfcontent);
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->render();

        //echo $this->pdfheader.$this->pdfcontent;
        $this->pdfcontent = '';
        //exit();

        $dompdf->stream('spendly_report.pdf');
    }
}
?>

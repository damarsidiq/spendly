const electron = require('electron')
const app = electron.app
const BrowserWindow = electron.BrowserWindow

let win

const {ipcMain} = require('electron')
ipcMain.on('asynchronous-message', (event, arg) => {
  if(arg.split('<edsep>')[0] == 'quitbro'){
    win.destroy();
  }
})

function draw() {
    win = new BrowserWindow({icon:'/media/damarsidiq/pic/icons/spendlyicon.png', width: 930, height: 569, resizable: true,x:205,y:0});
    win.webContents.session.clearCache(function(){});
    win.setTitle('Spendly');
    //win.setMenu(null);
    win.setMenuBarVisibility(false);
    win.isMaximizable(true);
    win.isResizable(true);
    win.setAlwaysOnTop(false, "floating");
    win.loadURL('http://pxpedia/pxpedia/?app=spendly&d[electronapp]=1');
    win.show();
}
app.on('ready', draw)

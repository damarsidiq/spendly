var categoryid          = 0;
var confirmbox          = false;
var total               = 0;
var filteredtotal       = 0;
var currentloadedlist   = [];
var activeloadedlist    = 0;
var focusedwish         = false;
var newwishflag         = false;
var filteroutlayflag    = false;
var focusedoutlay       = false;
var totalbudget         = false;
var totalwish           = false;
var activefilteroutlay  = false;
var filteredtotal       = 0;
var thereportvar        = [];
var markedpos           = false;
var tinyready           = false;
var odesccount          = 0;
var movingitemposition  = 0;
var marked              = false;
var movingitemheight    = 0;

function adjustbgbybudget(){
    if($('.list.active').attr('id') == 'wishlist'){
        if((totalbudget-totalwish) >= 500000){
            $('body').css('background-color','#3c0707');
        }
        else if((totalbudget-totalwish) >=300000){
            $('body').css('background-color','#431b8a');
        }
        else if((totalbudget-totalwish) >= 100000){
            $('body').css('background-color','#2e2e3c');
        }
        else{
            $('body').css('background-color','#8a8a30');
        }
        return;
    }
    if(totalbudget >= 500000){
        $('body').css('background-color','#3c0707');
    }
    else if(totalbudget >=300000){
        $('body').css('background-color','#431b8a');
    }
    else if(totalbudget >= 100000){
        $('body').css('background-color','#2e2e3c');
    }
    else{
        $('body').css('background-color','#8a8a30');
    }
}
function prevodesccount(){
    return odesccount;
}
function odesccounter(){
    odesccount++;
    return odesccount;
}
function tinythentinynow(textid){
    textid = 'odesc_'+textid;
    var tinymcesetting = {
        theme: "modern",
        height:350,
		plugins: [
			"autolink link image lists charmap print preview hr anchor pagebreak",
			"searchreplace wordcount visualblocks visualchars fullscreen insertdatetime media nonbreaking",
			"save table contextmenu directionality emoticons template textcolor paste fullpage textcolor colorpicker"
		],
		toolbar1: "styleselect formatselect fontselect fontsizeselect bold italic underline strikethrough alignleft aligncenter alignright alignjustify removeformat insertimage",
		toolbar2: "cut copy paste pastetext outdent indent link unlink forecolor backcolor table hr subscript superscript bullist numlist charmap image insertdatetime emoticons",
		inline:true,
		add_unload_trigger: false,
		menubar: false,
        toolbar_items_size: 'small',
		style_formats: [
			{title: 'Bold text', inline: 'b'},
			{title: 'Red text', inline: 'span', styles: {color: '#ff0000'}},
			{title: 'Red header', block: 'h1', styles: {color: '#ff0000'}},
			{title: 'Example 1', inline: 'span', classes: 'example1'},
			{title: 'Example 2', inline: 'span', classes: 'example2'},
			{title: 'Table styles'},
			{title: 'Table row 1', selector: 'tr', classes: 'tablerow1'}
		]
    };
    tinymcesetting.selector = 'div#'+textid;
    var testiny = tinymce.init(tinymcesetting);
    if(tinyready=== false){
        testiny.then(function(){
            tinyready = true;
        },function(error){
        });   
    }
}
function searchloadedlist(theday,filtertype){
    for(var i=1;i<currentloadedlist.length;i++){
        if(currentloadedlist[i].filtertype == filtertype && currentloadedlist[i].filtervalue == theday)
        {
            return i;
        }
    }
    return false;
}
function updatewishorder(){
    var orderwish = [];
    $.each($('#wishlist').children(),function(wi,we){
        orderwish[orderwish.length] = $(we).attr('id').split('_')[1];
    });
    orderwish = orderwish.join('|');
    $.ajax({
        url:'./',
        type:'POST',
        data:{app:appname,p:'outlay',a:'sortwish',d:{order:orderwish}}
    }).done(function(msg){
    });
}
$(document).ready(function(){
    spendlylocal.init();
    
    thereportvar.title = 'Report Title';
    thereportvar.desc = 'Report Description';
    thereportvar.id = false;
    
    registaforminput('body','input[type="text"],input[type="password"],textarea,select');
  
    $.each($('#outlaycat').find('.catname'),function(ci,ce){
        $(ce).html($(ce).html().replace(' ','-'));
    });
  
    $.each($('#spending').children(),function(imm,elem){
        total += moneyamount($(elem).children('.amount').html());
    });
    $('#total').html(moneyformat(total,true));
    
    currentloadedlist[0] = [];
    currentloadedlist[0].list = $('#spending').html();
    currentloadedlist[0].total = total;
    currentloadedlist[0].filtervalue = '';
    currentloadedlist[0].filtertype = '';
    
    totalbudget = parseInt($('#thebudget').html());
    $('#thebudget').html(moneyformat(totalbudget,true));
    adjustbgbybudget();
  
    $('.categoryselectionopt').on('click',function(event){
        categoryid = $(this).attr('id').substr(10);
        
        if(newwishflag){
            newwishbox($(this).html());
        }
        else{
            if(filteroutlayflag){
                filteroutlay();
                return;
            }
            newoutlaybox($(this).html());    
        }
    });
    
    $('#pastreports').delegate('li','click',function(event){
        event.stopPropagation();
        var outlayid = $(this).attr('id').substr(12);
        loadingmessagebox();
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'outlay',a:'outlaydesc',d:{outlayid:outlayid}}
        }).done(function(msg){
            msg = JSON.parse(msg);
            if(msg != false){
                thereportvar.desc = msg.content;
                thereportvar.created = msg.created;
                
                var boxtitle = 'Report Description';
                var boxcontent = '<div class="row bottomless singleinput">'+msg.created+'</div>'
                +'<div class="row bottomless singleinput"><div name="Description" style="height:150px" class="odesc" id="odesc_'+odesccounter()+'">'+msg.content+'</div></div>';
                var boxaction = '<span id="reportitems">Details</span><span id="editreportitems">Edit</span><span id="pdfreportitems">PDF</span>';
                
                confirmbox = new messagebox();
                confirmbox.displayfunc(boxtitle,boxcontent,boxaction);
                
                $('#pdfreportitems').on('click',function(event){
                    event.stopPropagation();
                    
                    $.ajax({
                        url:'./',
                        type:'POST',
                        data:{app:appname,p:'ajax',a:'pdfreport',d:{reportid:outlayid}}
                    }).done(function(msg){
                        msg = JSON.parse(msg);
                        
                        window.open('./?app=spendly&p=ajax&a=downloadpdf&d[pdfid]='+msg.pdfid);
                    });
                });
                
                $('#editreportitems').on('click',function(event){
                    event.stopPropagation();
                    loadingmessagebox();
                      $.ajax({
                        url:'',
                        type:'POST',
                        data:{app:appname,p:'outlay',a:'thereport',d:{id:outlayid}}
                    }).done(function(msg){
                        msg = JSON.parse(msg);
                        thereportvar.title = $('#pastreports_'+outlayid).children('.title').html();
                        thereportvar.id = outlayid;
                        
                        $('#report').html('');
                        var tempnewndate;
                        $.each(msg,function(ri,re){
                            $('#report').append('<li id="report_'+re.id+'" class="'+re.created.split(' ')[0]+' reportitem"><span class="title">'+re.title+'</span><span class="amount">'+moneyformat(re.amount,false)+'</span></li>');
                            tempnewdate = re.created.split(' ')[0];
                            
                            if(typeof $('#report_'+re.id).prev().attr('class') === 'undefined' || tempnewdate != $('#report_'+re.id).prev().attr('class').split(' ')[0]){
                                if(typeof $('#report_'+re.id).next().attr('class') === 'undefined' || tempnewdate != $('#report_'+re.id).next().attr('class').split(' ')[0]){
                                    $('#report_'+re.id).children('.title').after('<span class="theday">'+tempnewdate+'</span>');
                                    $('#report_'+re.id).addClass('changeofday');   
                                }
                            }
                        });
                        
                        $('.list').removeClass('active');
                        $('#report').addClass('active');
                        
                        confirmbox.close();
                        adjustbread();
                        adjusttotal();
                        loadingmessagebox();
                    });
                });
                
                $('#reportitems').on('click',function(event){
                    event.stopPropagation();
                    loadingmessagebox();
                    $.ajax({
                        url:'',
                        type:'POST',
                        data:{app:appname,p:'outlay',a:'thereport',d:{id:outlayid}}
                    }).done(function(msg){
                        msg = JSON.parse(msg);
                        thereportvar.title = $('#pastreports_'+outlayid).children('.title').html();
                        
                        $('#currentreport').html('');
                        var tempnewndate;
                        $.each(msg,function(ri,re){
                            $('#currentreport').append('<li id="reportitem_'+re.id+'" class="'+re.created.split(' ')[0]+' '+re.category+' reportitem"><span class="title">'+re.title+'</span><span class="amount">'+moneyformat(re.amount,false)+'</span></li>');
                            tempnewdate = re.created.split(' ')[0];
                            if(typeof $('#reportitem_'+re.id).prev().attr('class') === 'undefined' || tempnewdate != $('#reportitem_'+re.id).prev().attr('class').split(' ')[0]){
                                if(typeof $('#reportitem_'+re.id).next().attr('class') === 'undefined' || tempnewdate != $('#reportitem_'+re.id).next().attr('class').split(' ')[0]){
                                    $('#reportitem_'+re.id).children('.title').after('<span class="theday">'+tempnewdate+'</span>');
                                    $('#reportitem_'+re.id).addClass('changeofday');   
                                }
                            }
                        });
                        
                        $('.list').removeClass('active');
                        $('#currentreport').addClass('active');
                        
                        confirmbox.close();
                        adjustbread();
                        adjusttotal();
                        loadingmessagebox();
                    });
                });
            }
            loadingmessagebox();
        });
    });
    
    $('#spending').delegate('.theday','click',function(event){
        event.stopPropagation();
        var filtertype = '';
        var filtervalue = '';
        
        markedpos = $(this).html();
        if($(this).attr('class').indexOf('focused') !== -1){
            filtertype  = '';
            filtervalue = activefilteroutlay === false ? '' : activefilteroutlay;
            
            $('#loadolderoutlaymenu').removeClass('hide');
        }
        else{
            filtertype  = 'day';
            filtervalue = (activefilteroutlay === false || activeloadedlist == 0) ? $(this).html() : $(this).html() + ' ' +activefilteroutlay;
            
            $('#loadolderoutlaymenu').addClass('hide');
        }
        
        if(activeloadedlist !== 0 && activefilteroutlay === false){
            $('#spending').html(currentloadedlist[0].list);
            activeloadedlist = 0;
            adjusttotal();
            adjustbread();
            return;
        }
        else if(activefilteroutlay !== false && activeloadedlist === 0){
            filteredtotal = 0;
            
            currentloadedlist[activeloadedlist].list = $('#spending').html();
            
            if($(this).attr('class').indexOf('focused') !== -1){
                activeloadedlist = searchloadedlist(activefilteroutlay,'cat');
                $('#spending').html(currentloadedlist[activeloadedlist].list);
                adjusttotal();
                adjustbread();
                return;
            }
            else{
                var fidx = searchloadedlist(filtervalue,filtertype);
                if(fidx !== false){
                    activeloadedlist = fidx;
                    $('#spending').html(currentloadedlist[activeloadedlist].list);
                    adjusttotal();
                    adjustbread();
                    return;
                }
                else{
                    currentloadedlist[activeloadedlist].list = $('#spending').html();
                }
            }
        }
        else if(activefilteroutlay !== false && activeloadedlist != 0){
            filteredtotal = 0;
            
            currentloadedlist[activeloadedlist].list = $('#spending').html();
            
            if($(this).attr('class').indexOf('focused') !== -1){
                if(activefilteroutlay.indexOf('^') !==-1){
                    filtertype = 'boundary';
                }
                else{
                    if(activefilteroutlay.indexOf('#') !==-1)
                        filtertype = 'keyword';
                    else if(activefilteroutlay.indexOf('~') !==-1 ){
                        filtertype = 'keyword';
                    }   
                }
                activeloadedlist = searchloadedlist(filtervalue,filtertype);
                if(activeloadedlist === false){
                    activeloadedlist = 0;
                    filteroutlay();
                    return;
                }
                $('#spending').html(currentloadedlist[activeloadedlist].list);
                adjustbread();
                adjusttotal();
                return;
            }
            else{
                var fidx = searchloadedlist(filtervalue,filtertype);
                if(fidx !== false){
                    activeloadedlist = fidx;
                    $('#spending').html(currentloadedlist[activeloadedlist].list);
                    adjusttotal();
                    adjustbread();
                    return;
                }
                else{
                    currentloadedlist[activeloadedlist].list = $('#spending').html();
                }
            }
        }
        else{
            currentloadedlist[0].list = $('#spending').html();            
        }
        
        var idx = searchloadedlist(filtervalue,filtertype);
        if(idx !== false){
            activeloadedlist = idx;
        }
        else{
            activeloadedlist = currentloadedlist.length;
            currentloadedlist[activeloadedlist] = [];
            currentloadedlist[activeloadedlist].total = 0;
            currentloadedlist[activeloadedlist].filtertype = filtertype;
            currentloadedlist[activeloadedlist].filtervalue = filtervalue;
        }
            $('#spending').children().addClass('hide');
            
            $(this).addClass('focused');   
            $(this).parent().addClass('active');
            var curelem = $(this).parent();
            var count=1;
            currentloadedlist[activeloadedlist].total = moneyamount($(curelem).children('.amount').html());
            
            while(typeof $(curelem).next().attr('class') !== 'undefined' && $(curelem).next().attr('class').indexOf('changeofday') === -1 ){
                count++;
                curelem = $(curelem).next();
                $(curelem).addClass('active');
                
                if(activefilteroutlay !== false && activefilteroutlay.indexOf('#') === -1 && activefilteroutlay.indexOf('~') === -1){
                    if($(curelem).attr('class').split(' ')[1] != activefilteroutlay){
                        $(curelem).addClass('hide').removeClass('active');
                    }
                    else{
                        currentloadedlist[activeloadedlist].total += moneyamount($(curelem).children('.amount').html());
                        $(curelem).removeClass('hide').removeClass('active');
                    }
                }
                else{
                    currentloadedlist[activeloadedlist].total += moneyamount($(curelem).children('.amount').html());
                }
            }
            
            loadingmessagebox();
            $.ajax({
                url:'./',
                type:'POST',
                data:{app:appname,p:'outlay',a:'filteredoutlay',d:{type:currentloadedlist[activeloadedlist].filtertype,value:currentloadedlist[activeloadedlist].filtervalue,offset:count}}
            }).done(function(msg){
                msg = JSON.parse(msg);
                if(msg !== false){
                    var hide = false;
                    $.each(msg,function(oi,oe){
                        $(curelem).after('<li id="outlay_'+oe.id+'"><span class="title">'+oe.title+'</span><span class="amount">'+oe.amount+'</span></li>');
                        $('#outlay_'+oe.id).addClass(oe.created.split(' ')[0]);
                        $('#outlay_'+oe.id).addClass(oe.category);
                        
                        curelem = $('#outlay_'+oe.id);
                        
                        if(activefilteroutlay !== false){
                            if(oe.category != activefilteroutlay){
                                $('#outlay_'+oe.id).addClass('hide');
                                hide = true;
                            }
                            else{
                                hide = false;
                            }
                        }
                        else{
                        }
                        if(!hide){
                            currentloadedlist[activeloadedlist].total += moneyamount($(curelem).children('.amount').html());   
                        }
                    });
                    
                    currentloadedlist[activeloadedlist].list = $('#spending').html();
                    $('#total').html(moneyformat(currentloadedlist[activeloadedlist].total,true));
                }
                adjustbread();
                loadingmessagebox();
            });
    });
    
    $('#spending').delegate('li','click',function(event){
        focusedoutlay = parseInt($(this).attr('id').substr(7));
        outlaydescbox();
    });
    
    $('#currentreport').delegate('li','click',function(event){
        focusedoutlay = parseInt($(this).attr('id').substr(11));
        outlaydescbox();
    });
    
    $('#report').delegate('li','click',function(event){
        focusedoutlay = parseInt($(this).attr('id').substr(7));
        outlaydescbox();
    });
    
    $('body').delegate('#removefromreport','click',function(event){
        switch($('.list.active').attr('id')){
            case 'currentreport':
                $('#reportitem_'+focusedoutlay).remove();
                confirmbox.close();
                adjusttotal();
                adjustbread();
            break;
            case 'report':
                $('#report_'+focusedoutlay).remove();
                confirmbox.close();
                adjusttotal();
                adjustbread();
            break;
        }
    });
    
    
    if(ismobile){
        $('#wishlist').delegate('.moving','touchmove',function(event){
            event.preventDefault();
            var movingitempositiony = (event.originalEvent.touches[0].clientY);
            $('#wishlist .moving').css('top',movingitempositiony-$('#wishlist')[0].offsetTop-movingitemheight);
            if(movingitempositiony > movingitemposition && movingitempositiony  - movingitemposition > movingitemheight){
                movingitemposition = movingitempositiony;
                marked = markplace(marked,'next');
            }
            else if(movingitempositiony < movingitemposition && movingitemposition - movingitempositiony > movingitemheight){
                movingitemposition = movingitempositiony;
                marked = markplace(marked,'prev');
            }
        });   
        $('#wishlist').delegate('li','touchstart',function(event){
            if(event.originalEvent.target.className.indexOf('amount')!==-1){
                if(event.originalEvent.target.className.indexOf('skip')===-1){
                    $(event.originalEvent.target).addClass('skip');
                    spendlylocal.updatelocal(true,$(event.originalEvent.target).siblings('.title').html(),$(event.originalEvent.target).html());
                }
                else{
                    $(event.originalEvent.target).removeClass('skip');
                    spendlylocal.updatelocal(false,$(event.originalEvent.target).siblings('.title').html(),$(event.originalEvent.target).html());
                }
                adjusttotal();
                adjustbread();
                adjustbgbybudget();
                return;
            }
            focusedwish = $(this).attr('id').substr(5);
            if($(this).children('.amount').attr('class').indexOf('skip') !== -1){
                return;
            }
            
            $(this).addClass('touchstart');
            setTimeout(function(){
                $('#wishlist .touchstart').removeClass('touchstart');
            },150);
            movingitemposition = event.originalEvent.touches[0].clientY;
            
            setTimeout(function() {
                if(typeof $('#wish_'+focusedwish).attr('class') === 'undefined' || (typeof $('#wish_'+focusedwish).attr('class') !== 'undefined' && $('#wish_'+focusedwish).attr('class').indexOf('touchstart')===-1 && $('#wish_'+focusedwish).attr('class').indexOf('aclick')===-1)){
                    movingitemheight = $('#wish_'+focusedwish).height();
                    marked = markplace(marked,false);
                    $('#wish_'+focusedwish).addClass('moving');
                    $('#wishlist .moving').css('top',movingitemposition-$('#wishlist')[0].offsetTop-movingitemheight);
                }
            }, 1000);
            $(this).on('touchend',function(event){
                event.stopPropagation();
                if(event.originalEvent.target.className.indexOf('amount')!==-1){
                    return;
                }
                //return;
                if(typeof $(this).attr('class') === 'undefined' || (typeof $(this).attr('class') !== 'undefined' && $(this).attr('class').indexOf('moving')===-1)){
                    $(this).addClass('aclick');
                    setTimeout(function(){
                        $('#wish_'+focusedwish).removeClass('aclick');
                    },1000);
                        if(marked !==false){
                            $(marked).removeClass('marked');
                        }
                        marked = false;
                        
                        if($(this).attr('class').indexOf('touchstart')!==-1){
                            var itemname = $('#wish_'+focusedwish).children('.title').html();
                            var itemval = $('#wish_'+focusedwish).children('.amount').html();
                            confirmwishitem(itemname,itemval);   
                        }
                }
                else{
                    setTimeout(function(){
                        $('#wishlist .moving').removeClass('moving');
                    },100);
                    $(marked).after(this);
                    $(marked).removeClass('marked');
                    marked = false;
                    updatewishorder();
                }
            });
        });
    }
    else{
        $('#wishlist').delegate('li','mousedown',function(event){
            event.stopPropagation();
            if(event.target.className.indexOf('amount')!==-1){
                return;
            }
            focusedwish = $(this).attr('id').substr(5);
            if($(this).children('.amount').attr('class').indexOf('skip') !== -1){
                return;
            }
            
            $(this).addClass('touchstart');
            setTimeout(function(){
                $('#wishlist .touchstart').removeClass('touchstart');
            },250);
            
            movingitemposition = event.clientY;
            setTimeout(function() {
                if(typeof $('#wish_'+focusedwish).attr('class') === 'undefined' || (typeof $('#wish_'+focusedwish).attr('class') !== 'undefined' && $('#wish_'+focusedwish).attr('class').indexOf('aclick')===-1)){
                    movingitemheight = $('#wish_'+focusedwish).height();
                    marked = markplace(marked,false);
                    $('#wish_'+focusedwish).addClass('moving');
                    $('#wishlist .moving').css('top',movingitemposition-$('#wishlist')[0].offsetTop-movingitemheight);
                }
            }, 1000);
            
        });
        $('#wishlist').delegate('li','mouseup',function(event){
            if(event.target.className.indexOf('amount')!==-1){
                return;
            }
            if(typeof $(this).attr('class') === 'undefined' || (typeof $(this).attr('class') !== 'undefined' && $(this).attr('class').indexOf('moving')===-1)){
                $(this).addClass('aclick');
                setTimeout(function(){
                    $('#wish_'+focusedwish).removeClass('aclick');
                },1000);
                    if(marked !==false){
                        $(marked).removeClass('marked');
                    }
                    marked = false;
                
                    var itemname = $('#wish_'+focusedwish).children('.title').html();
                    var itemval = $('#wish_'+focusedwish).children('.amount').html();
                    confirmwishitem(itemname,itemval);
            }
            else{
                setTimeout(function(){
                    $('#wishlist .moving').removeClass('moving');
                },100);
                $(marked).after(this);
                $(marked).removeClass('marked');
                marked = false;
                updatewishorder();
            }
        });   
        $('#wishlist').delegate('.moving','mousemove',function(){
            var movingitempositiony = (event.clientY);
            $('#wishlist .moving').css('top',movingitempositiony-$('#wishlist')[0].offsetTop-movingitemheight);
            if(movingitempositiony > movingitemposition && movingitempositiony  - movingitemposition > movingitemheight){
                movingitemposition = movingitempositiony;
                marked = markplace(marked,'next');
            }
            else if(movingitempositiony < movingitemposition && movingitemposition - movingitempositiony > movingitemheight){
                movingitemposition = movingitempositiony;
                marked = markplace(marked,'prev');
            }
        });
        $('#wishlist').delegate('li .amount','click',function(event){
            event.stopPropagation();
            
            if($(this).attr('class').indexOf('skip')===-1){
                $(this).addClass('skip');
                spendlylocal.updatelocal(true,$(this).siblings('.title').html(),$(this).html());
            }
            else{
                $(this).removeClass('skip');
                spendlylocal.updatelocal(false,$(this).siblings('.title').html(),$(this).html());
            }
            adjusttotal();
            adjustbread();
            adjustbgbybudget();
        });
    }
    function markplace(marked,mode){
        if(marked===false){
            if(typeof $('#wish_'+focusedwish).prev().attr('id') !=='undefined'){
                marked = $('#wish_'+focusedwish).prev();
            }
            else{
                if(typeof $('#wish_'+focusedwish).next().attr('id') !== 'undefined'){
                     marked = $('#wish_'+focusedwish).next();
                }
            }
        }
        else{
            $(marked).removeClass('marked');
            if(mode == 'prev'){
                if(typeof $(marked).prev().attr('id') !== 'undefined'){
                    marked = $(marked).prev();
                }
                else{
                    $(marked).addClass('marked');
                    return marked;
                }
            }
            else{
                if(typeof $(marked).next().attr('id') !== 'undefined'){
                    marked = $(marked).next();
                }
                else{
                    $(marked).addClass('marked');
                    return marked;
                }
            }
            
            if(typeof $(marked).attr('class') !== 'undefined' && $(marked).attr('class').indexOf('moving') !== -1){
                return markplace(marked,mode);
            }
        }
        $(marked).addClass('marked');
        return marked;
    }
    $('#gosuggest').on('click',function(event){
        event.stopPropagation();
        
        spendingsuggfn();
    });
    $('#sugg_budget').on('keyup',function(event){
        event.stopPropagation();
        
        if(event.which==13){
            spendingsuggfn();
        }
    });
    $('#sugg_duration').on('keyup',function(event){
        event.stopPropagation();
        
        if(event.which==13){
            spendingsuggfn();
        }
    });
    
    $('#searchbudgetkey').on('keyup',function(event){
        event.stopPropagation();
        
        if(event.which==13){
            searchbudgetfn();
        }
    });
    $('#gosearchbudget').on('click',function(event){
        event.stopPropagation();
        
        searchbudgetfn();
    });
    $('#searchoutlaykey').on('keyup',function(event){
        event.stopPropagation();
        
        if(event.which==13){
            searchoutlayfn();
        }
    });
    $('#gosearchoutlay').on('click',function(event){
        event.stopPropagation();
        
        searchoutlayfn();
    });
    $('.menuitem').on('click',function(event){
        switch($(this).html()){
            case 'New Outlay':
                newwishflag = false;
                $('#menu').removeClass('active');
                $('#outlaycat').addClass('active');
            break;
            case 'Remove Filter':
                remfilterfn(false);
            break;
            case 'Filter Outlay':
                newwishflag = false;
                filteroutlayflag = true;
                $('#menu').removeClass('active');
                $('#outlaycat').addClass('active');
            break;
            case 'Search':
                newwishflag = false;
                filteroutlayflag = true;
                $('#menu').removeClass('active');
                $('#searchoutlay').addClass('active');
            break;
            case 'Search Budget':
                newwishflag = false;
                filteroutlayflag = true;
                $('#menu').removeClass('active');
                $('#searchbudgetpage').addClass('active');
            break;
            case 'Reset Search':
                $('#searchmenu').removeClass('hide');
                $('#searchbudget').removeClass('hide');
                $('#resetsearch').addClass('hide');
                
                resetsearchfn();
            break;
            case 'Spending Suggestions':
                newwishflag = false;
                filteroutlayflag = true;
                $('#menu').removeClass('active');
                $('#spendingsugg').addClass('active');
            break;
            case 'Reset Suggestions':
                $('#spendsugg').removeClass('hide');
                $('#resetsugg').addClass('hide');
                $('.menuitem').eq(3).removeClass('hide');
                
                
                remfilterfn(true);
                
                newwishflag = false;
                filteroutlayflag = true;
                $('#menu').removeClass('active');
                $('#spendingsugg').addClass('active');
                
                $('#spending').removeClass('active');
            break;
            case 'Report':
                newwishflag = false;
                filteroutlayflag = false;
                $('#menu').removeClass('active');
                $('#report').addClass('active');
                adjustbread();
                adjusttotal();
            break;
            case 'Reset Report':
                newwishflag = false;
                filteroutlayflag = false;
                $('#menu').removeClass('active');
                $('#removefiltermenu').addClass('hide');
                $('#report').html('');
                $('#report').addClass('active');
                adjusttotal();
                adjustbread();
            break;
            case 'Past Reports':
                newwishflag = false;
                filteroutlayflag = false;
                $('#menu').removeClass('active');
                $('#pastreports').addClass('active');
                adjusttotal();
                adjustbread();
            break;
            case 'Wishlist':
                $('#menu').removeClass('active');
                $('#wishlist').addClass('active');
                adjusttotal();
                adjustbread();
            break;
            case 'New Wish':
                newwishflag = true;
                $('#menu').removeClass('active');
                $('#outlaycat').addClass('active');
            break;
            case 'Load Older Outlay':
                loadolderoutlay();
            break;
            case 'Budget Summary':
                newwishflag = false;
                $('#menu').removeClass('active');
                $('#budgetlist').addClass('active');
                adjusttotal();
            break;
            case 'Load Older Budget':
                newwishflag = false;
                loadolderbudget();
            break;
            case 'Generate Time Based Report':
                tbasedreport();
            break;
            case 'Add Budget':
                addbudgetbox();
            break;
            case 'Exit':
                ipcRenderer.send('asynchronous-message', 'quitbro<edsep>');
            break;
        }
    });
    $('#logo').on('click',function(event){
        switch($('.list.active').attr('id')){
            case 'pastreports':
                $('#pastreports').removeClass('active');
                $('#spending').addClass('active');
                adjusttotal();
                adjustbread();
            break;
            case 'currentreport':
                $('#currentreport').removeClass('active');
                $('#pastreports').addClass('active');
                adjusttotal();
                adjustbread();
            break;
            case 'report':
                $('#report').removeClass('active');
                $('#spending').addClass('active');
                adjusttotal();
                adjustbread();
            break;
            case 'wishlist':
                $('#wishlist').removeClass('active');
                $('#spending').addClass('active');
                adjusttotal();
                adjustbread();
                adjustbgbybudget();
            break;
            case 'budgetlist':
                $('#budgetlist').removeClass('active');
                $('#spending').addClass('active');
                adjusttotal();
            break;
            case 'spending':
                $('#spending').removeClass('active');
                $('#menu').addClass('active');
            break;
            case 'menu':
                $('#menu').removeClass('active');
                $('#spending').addClass('active');
            break;
            case 'outlaycat':
                newwishflag = false;
                $('#outlaycat').removeClass('active');
                $('#spending').addClass('active');
            break;
            case 'searchoutlay':
                newwishflag = false;
                $('#searchoutlay').removeClass('active');
                $('#spending').addClass('active');
            break;
            case 'searchbudgetpage':
                newwishflag = false;
                $('#searchbudgetpage').removeClass('active');
                $('#spending').addClass('active');
            break;
            case 'spendingsugg':
                newwishflag = false;
                $('#spendingsugg').removeClass('active');
                $('#spending').addClass('active');
            break;
        }
    });
    $('#logo').delegate('.savereport','click',function(event){
        event.stopPropagation();  
        
        thereportvar.total = 0;
        $.each($('#report').children(),function(ri,re){
            thereportvar.total += moneyamount($(re).children('.amount').html());
        });
        var boxtitle = 'Save Report';
        var boxcontent = '<div class="row bottomless singleinput"><input type="text" value="'+thereportvar.title+'" name="Report Title" class="otitle"></div>'
        +'<div class="row bottomless singleinput"><input type="text" value="'+thereportvar.total+'" name="Amount" class="oamount"></div>'
        +'<div class="row bottomless singleinput"><div name="Report Description" style="height:150px" class="odesc" id="odesc_'+odesccounter()+'">'+thereportvar.desc+'</div></div>';
        var boxaction = '<span id="confirmnewoutlay">Confirm</span>';
        
        confirmbox = new messagebox();
        confirmbox.displayfunc(boxtitle,boxcontent,boxaction);
        tinythentinynow(prevodesccount());
    });
    $('body').delegate('.oamount','keyup',function(event){
        event.stopPropagation();
        if(event.which==13){
            var otitle = $('#messagebox').find('.otitle').val();
            var oamount = $('#messagebox').find('.oamount').val();
            var odesc = $('#messagebox').find('.odesc').html();
            if(otitle == 'Item Name' || oamount == 'Amount' || otitle == '' || oamount == ''){
                confirmbox.dispmsg('incomplete information',true);
                return;
            }
            var mode = $('#messagebox').find('#messageboxtitle').html();
                
            sendnewoutlay(otitle,oamount,odesc,mode);   
        }
    });
    $('body').delegate('.otitle','keyup',function(event){
        event.stopPropagation();
        if(event.which==13){
            var otitle = $('#messagebox').find('.otitle').val();
            var oamount = $('#messagebox').find('.oamount').val();
            var odesc = $('#messagebox').find('.odesc').html();
            if(otitle == 'Item Name' || oamount == 'Amount' || otitle == '' || oamount == ''){
                confirmbox.dispmsg('incomplete information',true);
                return;
            }
            var mode = $('#messagebox').find('#messageboxtitle').html();
                
            sendnewoutlay(otitle,oamount,odesc,mode);   
        }
    });
    
    $('body').delegate('#confirmnewoutlay','click',function(event){
        var otitle = $('#messagebox').find('.otitle').val();
        var oamount = $('#messagebox').find('.oamount').val();
        var odesc = $('#messagebox').find('.odesc').html();
        if(otitle == 'Item Name' || oamount == 'Amount' || otitle == '' || oamount == ''){
            confirmbox.dispmsg('incomplete information',true);
            return;
        }
        var mode = $(this).parent().siblings('#messageboxtitle').html();
            
        sendnewoutlay(otitle,oamount,odesc,mode);
    });
});

function outlaydescbox(){
    loadingmessagebox();
    $.ajax({
        url:'./',
        type:'POST',
        data:{app:appname,p:'outlay',a:'outlaydesc',d:{outlayid:focusedoutlay}}
    }).done(function(msg){
        msg = JSON.parse(msg);
        if(msg !== false){
            var boxtitle = '';
            var boxcontent = '<div class="row bottomless singleinput"><input type="text" value="'+msg.created+'"></div>'
                            +'<div class="row bottomless singleinput"><div name="Description" style="height:150px" class="odesc" id="odesc_'+odesccounter()+'">'+msg.content+'</div></div>';
            
            
            var boxaction = '';
            switch($('.list.active').attr('id')){
                case 'spending':
                    boxtitle += 'Outlay Description - '+$('#outlay_'+focusedoutlay).children('.title').html();
                    boxaction = '<span id="addtoreport">add to report</span>';
                break;
                case 'currentreport':
                    boxtitle += 'Outlay Description - '+$('#reportitem_'+focusedoutlay).children('.title').html();
                    boxaction = '';
                break;
                case 'report':
                    boxtitle += 'Outlay Description - '+$('#report_'+focusedoutlay).children('.title').html();
                    boxaction = '<span id="removefromreport">remove</span>';
                break;
            }                
                
            
            
            confirmbox = new messagebox();
            confirmbox.displayfunc(boxtitle,boxcontent,boxaction); 
            
            $('#addtoreport').on('click',function(event){
                event.stopPropagation();
                
                if($('#report').children().length){
                    var tempnewdate = $('#outlay_'+focusedoutlay).attr('class').split(' ')[0];
                    var temptheday = tempnewdate.split('-');
                    var curdate;
                    var curtheday;
                    var thistheplace = false;
                    for(var o=0;o<$('#report').children().length;o++){
                        curdate = $('#report').children().eq(o).attr('class').split(' ')[0];
                        curtheday = curdate.split('-');
                        
                        for(var io=0;io<3;io++){
                            if(curtheday[io] < temptheday[io]){
                                thistheplace = true;
                                break;
                            }
                        }
                        if(thistheplace){
                            $('#report').children().eq(o).before('<li id="report_'+focusedoutlay+'" class="'+$('#outlay_'+focusedoutlay).attr('class')+'">'+$('#outlay_'+focusedoutlay).html()+'</li>');
                            break;
                        }
                    }
                    if(!thistheplace)
                        $('#report').append('<li id="report_'+focusedoutlay+'" class="'+$('#outlay_'+focusedoutlay).attr('class')+'">'+$('#outlay_'+focusedoutlay).html()+'</li>');
                            
                    if(typeof $('#report_'+focusedoutlay).prev().attr('class') === 'undefined' || tempnewdate != $('#report_'+focusedoutlay).prev().attr('class').split(' ')[0]){
                        if(!$('#report_'+focusedoutlay).children('.theday').length){
                            if(typeof $('#report_'+focusedoutlay).next().attr('class') === 'undefined' || tempnewdate != $('#report_'+focusedoutlay).next().attr('class').split(' ')[0]){
                                $('#report_'+focusedoutlay).children('.title').after('<span class="theday">'+tempnewdate+'</span>');
                                $('#report_'+focusedoutlay).addClass('changeofday');   
                            }
                        }
                    }
                    else{
                        if($('#report_'+focusedoutlay).children('.theday').length){
                            $('#report_'+focusedoutlay).children('.theday').remove(); 
                            $('#report_'+focusedoutlay).removeClass('changeofday');
                        }
                    }
                }
                else{
                    $('#removefiltermenu').removeClass('hide');
                    $('#report').append('<li id="report_'+focusedoutlay+'" class="'+$('#outlay_'+focusedoutlay).attr('class')+'">'+$('#outlay_'+focusedoutlay).html()+'</li>');
                    if(!$('#report_'+focusedoutlay).children('.theday').length){
                        $('#report_'+focusedoutlay).children('.title').after('<span class="theday">'+$('#outlay_'+focusedoutlay).attr('class').split(' ')[0]+'</span>');
                        $('#report_'+focusedoutlay).addClass('changeofday');
                    }
                }
                
                confirmbox.close();
                $('#spending').removeClass('active');
                $('#report').addClass('active');
                adjusttotal();
                adjustbread();
            });
        }
        loadingmessagebox();
    });
}


function moneyformat(amount,currency){
    amount = amount.toString();
    var amountmoney = '';
    for(var i=amount.length-1;i>=0;i--){
        amountmoney = amount[i]+amountmoney;
        if(((amount.length-i) % 3) == 0 && i != 0){
            amountmoney = ','+amountmoney;
        }
    }
    if(currency)
        return 'Rp '+amountmoney;
        
    return amountmoney;
}

function tbasedreport(){
    $('#menu').removeClass('active');
    $('#budgetlist').addClass('active');
            
    var boxtitle = 'Time Based Report';
    var boxcontent = '<div class="row bottomless"><input type="text" value="start date" name="start date" class="tbr_input first datefield" id="tbr_startdate"><input type="text" value="end date" name="end date" class="tbr_input second datefield" id="tbr_enddate"></div>'
    +'<div class="row bottomless singleinput"><select id="reptype"><option value="Outlay">Outlay</option><option value="Income">Income</option><option value="Wishlist">Wishlist</option><option value="Category">Category</option></select></div>'
    +'<div class="row bottomless singleinput"><select id="sorttype"><option value="newest">Latest</option><option value="oldest">Oldest</option><option value="lowestprice">Lowest Price</option><option value="highestprice">Highest Price</option></select></div>'
    +'<div class="tbasedinput" id="tbr_content"></div>';
    var boxaction = '<span id="pdftbr">PDF</span><span id="gentbr">Generate</span>';
    
    confirmbox = new messagebox();
    confirmbox.displayfunc(boxtitle,boxcontent,boxaction);
    
    $('#reptype').on('change',function(event){
        event.stopPropagation();
        
        if($(this).val() == 'Category'){
            var seltbrcategory = '<select id="tbrcategory">';
            $.each($('#outlaycat').children(),function(ci,ce){
                seltbrcategory+='<option value="'+$(ce).attr('id').split('_')[1]+'">'+ $(ce).children().html() +'</option>';
            });
            seltbrcategory+='</select>';
            
            $(this).parent().after('<div id="seltbrcategory" class="row bottomless singleinput">'+seltbrcategory+'</div>');
        }
        else{
            if($(this).parent().next().attr('id') == 'seltbrcategory'){
                $(this).parent().next().remove();
            }
        }
    });
    $('#sorttype').on('change',function(event){
        event.stopPropagation();
        
        gentbrresult.updatesort();
    });
    $('#messagebox').find('.datefield').datepicker({
		dateFormat: "yy-mm-dd",
		changeYear:false,changeMonth:false
	});
	$('#gentbr').on('click',function(event){
	    event.stopPropagation();
	    
	    var sdate = $('#tbr_startdate').val();
	    var edate = $('#tbr_enddate').val();
	    var reptype = $('#reptype').val();
	    
	    if((sdate == 'start date' || edate == 'end date') && (reptype!='Wishlist')){
	        return;
	    }
	    if(reptype=='Category'){
	        reptype+='_'+$('#seltbrcategory').children().val();
	    }
	    generaterep(sdate,edate,reptype);
	});
	$('#pdftbr').on('click',function(event){
	    event.stopPropagation();
	    
	    var tbr_content = $('#tbr_content').html();
	    if(tbr_content == ''){
	        return;
	    }
	    loadingmessagebox();
	    $.ajax({
	        url:'./',
	        type:'POST',
	        data:{app:appname,p:'ajax',a:'tbr_pdf',d:{content:tbr_content}}
	    }).done(function(msg){
	        msg = JSON.parse(msg);
	        loadingmessagebox();
	        window.open('./?app=spendly&p=ajax&a=downloadpdf&d[pdfid]='+msg.pdfid);
	    });
	});
}
function loadingmessagebox(){
    if($('#messagebox').attr('class').indexOf('loading') === -1){
        $('#messagebox').addClass('loading');
        return;
    }
    $('#messagebox').removeClass('loading');
}
var gentbrresult = {
    result:false,
    total:false,
    sorttype:'newest',
    newresult:function(msg){
        this.result = msg.tbr_content;
        this.total = msg.total;
        this.sorttype = $('#messagebox').find('#sorttype').val();
        
        this.displayres();
        loadingmessagebox();
    },
    updatesort:function(){
        if(this.result === false){
            return;
        }
        loadingmessagebox();
        this.sorttype = $('#messagebox').find('#sorttype').val();
        
        this.displayres();
        loadingmessagebox();
    },
    displayres:function(){
        switch(this.sorttype){
            case 'highestprice':
                this.result.sort(function(a,v){
                    return parseInt(v.amount) - parseInt(a.amount);
                });
            break;
            case 'lowestprice':
                this.result.sort(function(a,v){
                    return parseInt(a.amount) - parseInt(v.amount);
                });
            break;
            case 'oldest':
                this.result.sort(function(a,v){
                    var ddate = a.datecreated.split('-');
                    var dtime = a.histime.split(':');
                    ddate = new Date(parseInt(ddate[0]),(parseInt(ddate[1])-1),parseInt(ddate[2]),dtime[0],dtime[1],dtime[2]);
                    
                    var ddate2 = v.datecreated.split('-');
                    var dtime2 = v.histime.split(':');
                    ddate2 = new Date(parseInt(ddate2[0]),(parseInt(ddate2[1])-1),parseInt(ddate2[2]),dtime2[0],dtime2[1],dtime2[2]);
        
                    return ddate-ddate2;
                });
            break;
            case 'newest':
                this.result.sort(function(a,v){
                    var ddate = a.datecreated.split('-');
                    var dtime = a.histime.split(':');
                    ddate = new Date(parseInt(ddate[0]),(parseInt(ddate[1])-1),parseInt(ddate[2]),dtime[0],dtime[1],dtime[2]);
                    
                    var ddate2 = v.datecreated.split('-');
                    var dtime2 = v.histime.split(':');
                    ddate2 = new Date(parseInt(ddate2[0]),(parseInt(ddate2[1])-1),parseInt(ddate2[2]),dtime2[0],dtime2[1],dtime2[2]);
        
                    return ddate2-ddate;
                });
            break;
        }
        var msg = [];
        msg.tbr_content = this.result;
        var repcont = '';
        var dateshow = false;
        for(var i=0;i<msg.tbr_content.length;i++){
            if(this.sorttype=='newest'||this.sorttype=='oldest'){
                if(dateshow==false){
                    dateshow = msg.tbr_content[i].datecreated;
                    msg.tbr_content[i].created = '<b>'+msg.tbr_content[i].created+'</b>';
                }
                else{
                    if(dateshow == msg.tbr_content[i].datecreated){
                        msg.tbr_content[i].created = msg.tbr_content[i].histime;
                    }
                    else{
                        dateshow = msg.tbr_content[i].datecreated;
                        msg.tbr_content[i].created = '<b>'+msg.tbr_content[i].created+'</b>';
                    }
                }   
            }
            repcont += '<div><b>'+(i+1)+'.  '+msg.tbr_content[i].title+'</b><span class="tbrtime">'+msg.tbr_content[i].created+'</span><br/>'+msg.tbr_content[i].amountformatted+'<br/><br/>'+msg.tbr_content[i].content+'<span class="outsepar"></span></div>';
        }
        repcont += '<div class="total">'+moneyformat(this.total,true)+'</div>';
        $('#tbr_content').html(repcont);
    }
};
function generaterep(sdate,edate,reptype){
    loadingmessagebox();
    $.ajax({
        url:'./',
        type:'POST',
        data:{app:appname,p:'ajax',a:'gen_tbr',d:{startdate:sdate,enddate:edate,reptype:reptype}}
    }).done(function(msg){
        msg = JSON.parse(msg);
        gentbrresult.newresult(msg);
    });
}
function addbudgetbox(){
    $('#menu').removeClass('active');
    $('#budgetlist').addClass('active');
            
    var boxtitle = 'Add Budget';
    var boxcontent = '<div class="row bottomless singleinput"><input type="text" value="Item Name" name="Item Name" class="otitle"></div>'
    +'<div class="row bottomless singleinput"><input type="text" value="Amount" name="Amount" class="oamount"></div>'
    +'<div class="row bottomless singleinput"><div name="Description" style="height:150px" class="odesc" id="odesc_'+odesccounter()+'"></div></div>';
    var boxaction = '<span id="confirmnewoutlay">Confirm</span>';
    
    confirmbox = new messagebox();
    confirmbox.displayfunc(boxtitle,boxcontent,boxaction);
    tinythentinynow(prevodesccount());
}
function confirmwishitem(itemname,itemval){
    loadingmessagebox();
    $.ajax({
        url:'./',
        type:'POST',
        data:{app:appname,p:'outlay',a:'outlaydesc',d:{outlayid:focusedwish}}
    }).done(function(msg){
        msg = JSON.parse(msg);
        if(msg !== false){
            var boxtitle = 'Confirm Wish';
            var boxcontent = '<div class="row bottomless singleinput"><input type="text" value="'+itemname+'" name="Item Name" class="otitle"></div>'
            +'<div class="row bottomless singleinput"><input type="text" value="'+itemval+'" name="Amount" class="oamount"></div>'
            +'<div class="row bottomless singleinput"><div name="Description" style="height:150px" class="odesc" id="odesc_'+odesccounter()+'">'+msg.content+'</div></div>';
            var boxaction = '<span id="confirmnewoutlay">Confirm</span><span id="updatewish">Update</span><span id="deletewish">Delete</span>';
            
            confirmbox = new messagebox();
            confirmbox.displayfunc(boxtitle,boxcontent,boxaction);
            tinythentinynow(prevodesccount());

            $('#updatewish').on('click',function(event){
                var otitle  = $('#messagebox').find('.otitle').val();
                var oamount = moneyamount($('#messagebox').find('.oamount').val());
                var odesc   = $('#messagebox').find('.odesc').html();
                if(otitle == 'Item Name' || oamount == 'Amount'){
                    return;
                }
                loadingmessagebox();
                $.ajax({
                    url:'./',
                    type:'POST',
                    data:{app:appname,p:'outlay',a:'updatewish',d:{wishid:focusedwish,title:otitle,amount:oamount,content:odesc}}
                }).done(function(msg){
                    msg = JSON.parse(msg);
                    loadingmessagebox();
                    if(msg.result == false){
                        errorbox(msg);
                        return
                    }
                    if(msg != false){
                        confirmbox.close();
                        $('#wish_'+focusedwish).children('.title').html(otitle);
                        $('#wish_'+focusedwish).children('.amount').html(moneyformat(oamount,false));
                        if(msg.result != 0){
                            $('#wish_'+focusedwish).prop('id','wish_'+msg.result);
                            focusedwish = msg.result;
                        }
                        adjusttotal();
                        adjustbread();
                        
                        updatewishorder();
                        
                        var skipped = $('#wish_'+focusedwish).find('.amount').attr('class').indexOf('skip') === -1 ? false : true;
                        spendlylocal.updatewish(skipped,otitle,oamount,$('#wish_'+focusedwish).children('.title').html(),$('#wish_'+focusedwish).children('.amount').html());
                    }
                });
            });

            
            $('#deletewish').on('click',function(event){
                loadingmessagebox();
                $.ajax({
                    url:'./',
                    type:'POST',
                    data:{app:appname,p:'outlay',a:'deletewish',d:{wishid:focusedwish}}
                }).done(function(msg){
                    msg = JSON.parse(msg);
                    if(msg != false){
                        confirmbox.close();
                        var oamount = $('#wish_'+focusedwish).find('.amount').html();
                        var otitle = $('#wish_'+focusedwish).find('.title').html();
                        $('#wish_'+focusedwish).remove();
                        adjusttotal();
                        adjustbread();
                        updatewishorder();
                        
                        var skipped = $('#wish_'+focusedwish).find('.amount').attr('class').indexOf('skip') === -1 ? false : true;
                        spendlylocal.deletewish(otitle,oamount);
                    }
                    loadingmessagebox();
                });
            });
        }
        loadingmessagebox();
    });
}
function loadolderbudget(){
    loadingmessagebox();
    $.ajax({
        url:'./',
        type:'POST',
        data:{app:appname,p:'outlay',a:'oldbudget',d:{offset:$('#budgetlist').children().length}}
    }).done(function(msg){
        msg = JSON.parse(msg);
        if(msg != false){
            var firstoflatest = false;
            $.each(msg,function(oi,oe){
                if(oi === 0){
                    firstoflatest = oe.id;
                }
                $('#budgetlist').append('<li id="budget_'+oe.id+'"><span class="title">'+oe.title+'</span><span class="amount">'+oe.amount+'</span></li>');
                $('#budget_'+oe.id).addClass(oe.created.split(' ')[0]);
                if(oe.created.split(' ')[0] != $('#budget_'+oe.id).prev().attr('class').split(' ')[0] ){
                    $('#budget_'+oe.id).addClass('changeofday');
                    $('#budget_'+oe.id).children().eq(0).after('<span class="theday">'+oe.created.split(' ')[0]+'</span>');
                }
            });
            $('#menu').removeClass('active');
            $('#budgetlist').addClass('active');
            
            
            if(firstoflatest !== false)
                $('#budget_'+firstoflatest)[0].scrollIntoView();
                
            adjusttotal();
        }
        loadingmessagebox();
    });
}
function loadolderoutlay(){
    var boxtitle = 'Requesting';
    var boxcontent = '<div class="row bottomless singleinput" style="text-align:center">Querying The Database...</div>';
    var boxaction = '';
    
    confirmbox = new messagebox();
    confirmbox.displayfunc(boxtitle,boxcontent,boxaction);
    
    loadingmessagebox();
    
    var offset = 0;
    $.each($('#spending').children(),function(si,se){
        if($(se).attr('class').indexOf('hide') === -1 || $(se).attr('class').indexOf('active') !== -1){
            offset += 1;
        }
    });
    $.ajax({
        url:'./',
        type:'POST',
        data:{app:appname,p:'outlay',a:'oldoutlay',d:{offset:offset,filter:activefilteroutlay}}
    }).done(function(msg){
        msg = JSON.parse(msg);
            if(msg.length==0){
                var boxtitle = 'No More Outlay';
                var boxcontent = '<div class="row bottomless singleinput" style="text-align:center">You Have Reached The Oldest Outlay of This Category</div>';
                var boxaction = '';
                
                confirmbox = new messagebox();
                confirmbox.displayfunc(boxtitle,boxcontent,boxaction);
                loadingmessagebox();
                $('.list').removeClass('active');
                $('#spending').addClass('active');
                
                return;
            }
        if(msg != false){
            var firstoflatest = false;
            var daytoremember = '';
            $.each($('#spending').children(),function(ix,im){
                if($(im).attr('class').indexOf('hide') === -1  || $(im).attr('class').indexOf('active') !== -1){
                    daytoremember = $(im).attr('class').split(' ')[0];
                }
            });
            $.each(msg,function(oi,oe){
                if(oi === 0){
                    firstoflatest = oe.id;
                }
                $('#spending').append('<li id="outlay_'+oe.id+'" class=""><span class="title">'+oe.title+'</span><span class="amount">'+oe.amount+'</span></li>');
                $('#outlay_'+oe.id).addClass(oe.created.split(' ')[0]);
                $('#outlay_'+oe.id).addClass(oe.category);
                
                if(activefilteroutlay !== false && activefilteroutlay.indexOf('#') !==0){
                    if(oe.category == activefilteroutlay){
                        currentloadedlist[activeloadedlist].total += moneyamount(oe.amount); 
                        if(daytoremember != oe.created.split(' ')[0]){
                            daytoremember = oe.created.split(' ')[0];  
                            $('#outlay_'+oe.id).addClass('changeofday');
                            $('#outlay_'+oe.id).children().eq(0).after('<span class="theday">'+oe.created.split(' ')[0]+'</span>');
                            if(currentloadedlist[activeloadedlist].filtertype.indexOf('day') !== -1){
                                if(currentloadedlist[activeloadedlist].filtervalue.split(' ')[0] == oe.created.split(' ')[0]){
                                    $('#outlay_'+oe.id).children('.theday').addClass('focused');
                                }
                            }
                        }
                    }
                    else{
                        $('#outlay_'+oe.id).addClass('hide');
                    }
                }
                else{
                    currentloadedlist[activeloadedlist].total += moneyamount(oe.amount); 
                    if(oe.created.split(' ')[0] != $('#outlay_'+oe.id).prev().attr('class').split(' ')[0] ){
                        $('#outlay_'+oe.id).addClass('changeofday');
                        $('#outlay_'+oe.id).children().eq(0).after('<span class="theday">'+oe.created.split(' ')[0]+'</span>');
                    }
                }
            });
            if(activefilteroutlay !== false){
                $('#total').html(moneyformat(currentloadedlist[activeloadedlist].total,true));
            }
            else{
                currentloadedlist[activeloadedlist].list = $('#spending').html();
                $('#total').html(moneyformat(currentloadedlist[activeloadedlist].total,true));
            }
            
            $('.list').removeClass('active');
            $('#spending').addClass('active');
            
            $('#messagebox').removeClass('active');
            loadingmessagebox();
            
            if(firstoflatest !== false)
                $('#outlay_'+firstoflatest)[0].scrollIntoView();
        }
    });
}
var spendlylocal = {
    initialized:false,
    wishitemexcludecount:false,
    init:function(){
        if(this.initialized){
            return;
        }
        this.getLocalStorage();
        if(this.localstorage === false)
            return;
        /*
        this.localstorage.setItem('spendlylocal',null);
        return;*/
        var test = this.localstorage.getItem('spendlylocal');
        if(test === null || test == 'null' || test == 'undefined' || test === ''){
            this.wishitemexcludecount = null;
            return;
        }
        this.wishitemexcludecount=JSON.parse(test);
        this.anticipatesync();
        this.updateexcludedwl();
        this.initialized=true;
    },
    anticipatesync:function(){
        for(var o=0;o<this.wishitemexcludecount.length;o++){
            if(typeof this.wishitemexcludecount[o].title ==='undefined')
                break;
                
            var remain=false;
            $.each($('#wishlist').children(),function(wi,we){
                if($(we).find('.title').html() == spendlylocal.wishitemexcludecount[o].title && $(we).find('.amount').html() == spendlylocal.wishitemexcludecount[o].amount){
                    remain = true;;
                    return false;
                }
            });
            if(!remain){
                this.wishitemexcludecount.splice(o,1);
                o--;
            }
        }
        this.notifbrowser();
    },
    notifbrowser:function(){
        this.localstorage.setItem('spendlylocal',JSON.stringify(this.wishitemexcludecount));
    },
    updatewish:function(skip,title,amount,otitle,oamount){
        this.deletewish(skip,otitle,oamount);
                
                this.wishitemexcludecount[this.wishitemexcludecount.length] = {title:title,amount:amount};
                
        this.notifbrowser();
    },
    deletewish:function(title,amount){
        for(var o=0;o<this.wishitemexcludecount.length;o++){
            if(this.wishitemexcludecount[o].title == title && this.wishitemexcludecount[o].amount == amount){
                this.wishitemexcludecount.splice(o,1);
                break;
            }
        }
        
        this.notifbrowser();
    },
    updatelocal:function(skip,title,amount){
        if(this.wishitemexcludecount==null){
            this.wishitemexcludecount = [];
        }
        if(skip){
            var exi = false;
            for(var o=0;o<this.wishitemexcludecount.length;o++){
                if(typeof this.wishitemexcludecount[o].title ==='undefined')
                    break;
                if(this.wishitemexcludecount[o].title == title && this.wishitemexcludecount[o].amount == amount){
                    exi = true;
                    break;
                }
            }   
            if(!exi){
                this.wishitemexcludecount[this.wishitemexcludecount.length] = {title:title,amount:amount};
            }
        }
        else{
            for(var o=0;o<this.wishitemexcludecount.length;o++){
                if(typeof this.wishitemexcludecount[o].title ==='undefined')
                    break;
                if(this.wishitemexcludecount[o].title == title && this.wishitemexcludecount[o].amount == amount){
                    this.wishitemexcludecount.splice(o,1);
                    break;
                }
            }
        }
        this.notifbrowser();
    },
    updateexcludedwl:function(){
        for(var o=0;o<this.wishitemexcludecount.length;o++){
            if(typeof this.wishitemexcludecount[o].title ==='undefined')
                break;
                
            $.each($('#wishlist').children(),function(wi,we){
                if($(we).find('.title').html() == spendlylocal.wishitemexcludecount[o].title && $(we).find('.amount').html() == spendlylocal.wishitemexcludecount[o].amount){
                    $(we).find('.amount').addClass('skip');
                    return false;
                }
            });
        }
    },
    localstorage:false,
    getLocalStorage:function(){
        if (typeof localStorage == "object"){
            this.localstorage =  localStorage;
        } else if (typeof globalStorage == "object"){
            this.localstorage = globalStorage[location.host];
        } else {
            this.localstorage = false;
        }
    }
};
function newwishbox(categoryname){
    var boxtitle = 'New Wish - '+categoryname;
    var boxcontent = '<div class="row bottomless singleinput"><input type="text" value="Item Name" name="Item Name" class="otitle"></div>'
    +'<div class="row bottomless singleinput"><input type="text" value="Amount" name="Amount" class="oamount"></div>'
    +'<div class="row bottomless singleinput"><div name="Description" style="height:150px" class="odesc" id="odesc_'+odesccounter()+'"></div></div>';
    var boxaction = '<span id="confirmnewoutlay">Confirm</span>';
    
    confirmbox = new messagebox();
    confirmbox.displayfunc(boxtitle,boxcontent,boxaction);
    tinythentinynow(prevodesccount());
}
function remfilterfn(reset){
    currentloadedlist[activeloadedlist].list = $('#spending').html();
    newwishflag         = false;
    filteroutlayflag    = false;
    activefilteroutlay  = false;
    filteredtotal       = 0;
    
    var breadcrumbscontent = '';
    var breadcrumbs = $('#breadcrumbscontent').html().split(' ');
    
    if(breadcrumbs.length > 1 && !reset){
        breadcrumbscontent  = breadcrumbs[0];
        activeloadedlist    = searchloadedlist(breadcrumbscontent,'day');
        if(activeloadedlist === false){
            activeloadedlist = currentloadedlist.length;
            currentloadedlist[activeloadedlist] = [];
            currentloadedlist[activeloadedlist].total = 0;
            currentloadedlist[activeloadedlist].list = '';
            currentloadedlist[activeloadedlist].filtertype = 'day';
            currentloadedlist[activeloadedlist].filtervalue = breadcrumbscontent;
            
            $('#breadcrumbscontent').html(breadcrumbscontent);
    
            $('#menu').removeClass('active');
            $('#removefiltermenu').addClass('hide');
            $('#spending').html('').addClass('active');
            loadingmessagebox();
            $.ajax({
                url:'./',
                type:'POST',
                data:{app:appname,p:'outlay',a:'filteredoutlay',d:{type:'day',value:currentloadedlist[activeloadedlist].filtervalue,offset:0}}
            }).done(function(msg){
                msg = JSON.parse(msg);
                if(msg !== false){
                    var hide = false;
                    $.each(msg,function(oi,oe){
                        if(oi == 0){
                            $('#spending').append('<li id="outlay_'+oe.id+'"><span class="title">'+oe.title+'</span><span class="amount">'+oe.amount+'</span></li>');
                        }
                        else{
                            $(curelem).after('<li id="outlay_'+oe.id+'"><span class="title">'+oe.title+'</span><span class="amount">'+oe.amount+'</span></li>');    
                        }
                        
                        $('#outlay_'+oe.id).addClass(oe.created.split(' ')[0]);
                        $('#outlay_'+oe.id).addClass(oe.category);
                        
                        if(oi == 0){
                            $('#outlay_'+oe.id).addClass('changeofday');
                            $('#outlay_'+oe.id).children('.title').after('<span class="theday focused">'+oe.created.split(' ')[0]+'</span>');
                        }
                        
                        curelem = $('#outlay_'+oe.id);
                        
                        if(activefilteroutlay !== false){
                            if(oe.category != activefilteroutlay){
                                $('#outlay_'+oe.id).addClass('hide');
                                hide = true;
                            }
                            else{
                                hide = false;
                            }
                        }
                        else{
                        }
                        if(!hide){
                            currentloadedlist[activeloadedlist].total += moneyamount($(curelem).children('.amount').html());   
                        }
                    });
                    
                    currentloadedlist[activeloadedlist].list = $('#spending').html();
                    $('#total').html(moneyformat(currentloadedlist[activeloadedlist].total,true));
                }
                adjustbread();
                loadingmessagebox();
            });
            return;
        }
    }
    else{
        breadcrumbscontent = '';
        activeloadedlist = 0;
        activefilteroutlay = false;
    }
    
    $('#menu').removeClass('active');
    $('#removefiltermenu').addClass('hide');
    $('#spending').html(currentloadedlist[activeloadedlist].list);
    $('#spending').addClass('active');
    adjustbread();
    adjusttotal();
}
function resetsearchfn(){
    activeloadedlist = 0;
    activefilteroutlay = false;
    $('#spending').html(currentloadedlist[activeloadedlist].list);
    
    $('.menuitem').eq(3).removeClass('hide');
    
    $('#menu').removeClass('active');
    $('#spending').addClass('active');
    
        adjusttotal();
        adjustbread();
}
function spendingsuggfn(){
    var boxtitle = 'Searching';
    var boxcontent = '<div class="row bottomless singleinput" style="text-align:center">Searching The Database...</div>';
    var boxaction = '';
    
    confirmbox = new messagebox();
    confirmbox.displayfunc(boxtitle,boxcontent,boxaction);
    
    loadingmessagebox();
    var filtertype  = 'boundary';
    var filtervalue = $('#sugg_budget').val()+'^'+$('#sugg_duration').val();
    
    if(filtervalue.indexOf('duration in day') !== -1 || filtervalue.indexOf('budget') !==-1 || filtervalue.indexOf('^') === 0 || filtervalue.indexOf('^') === (filtervalue.length-1) ){
        $('#messagebox').removeClass('active');
        loadingmessagebox();
        return;
    }
    remfilterfn(true);
    activefilteroutlay = '~'+filtervalue;
    
    $('#spendsugg').addClass('hide');
    $('#resetsugg').removeClass('hide');
    $('.menuitem').eq(3).addClass('hide');
    
    var fidx = searchloadedlist('~'+filtervalue,filtertype);
    if(fidx !== false){
        activeloadedlist = fidx;
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'suggest',a:'spendsuggestion',d:{keyword:currentloadedlist[activeloadedlist].filtervalue+'^'+currentloadedlist[activeloadedlist].startscons,offset:0,}}
        }).done(function(msg){
            msg = JSON.parse(msg);
            
            if(!msg.result.length){
                $('#spending').html(currentloadedlist[activeloadedlist].list);
                $('#spendingsugg').removeClass('active');
                $('#spending').addClass('active');
                
                $('#total').html(moneyformat(currentloadedlist[activeloadedlist].total,true));
                adjustbread();
                
                var boxtitle = 'Notice';
                var boxcontent = '<div class="row bottomless singleinput" style="text-align:center">Not much in the database with the given information</div>';
                var boxaction = '';
                
                confirmbox = new messagebox();
                confirmbox.displayfunc(boxtitle,boxcontent,boxaction);
            }
            else{
                $('#spending').html('');
                currentloadedlist[activeloadedlist].total = 0;
                msg.result.sort(function(a,v){
                    var cre = a.created.split(' ');
                    var ddate = cre[0].split('-');
                    var dtime = cre[1].split(':');
                    ddate = new Date(parseInt(ddate[0]),(parseInt(ddate[1])-1),parseInt(ddate[2]),dtime[0],dtime[1],dtime[2]);
                    
                    cre = v.created.split(' ');
                    var ddate_ = cre[0].split('-');
                    var dtime_ = cre[1].split(':');
                    ddate_ = new Date(parseInt(ddate_[0]),(parseInt(ddate_[1])-1),parseInt(ddate_[2]),dtime_[0],dtime_[1],dtime_[2]);
                    
                    return ddate_ - ddate;
                });
                currentloadedlist[activeloadedlist].startscons = msg.startscons;
                $.each(msg.result,function(oi,oe){
                    if(oi === 0){
                        firstoflatest = oe.id;
                    }
                    $('#spending').append('<li id="outlay_'+oe.id+'"><span class="title">'+oe.title+'</span><span class="amount">'+oe.amount+'</span></li>');
                    $('#outlay_'+oe.id).addClass(oe.created.split(' ')[0]);
                    $('#outlay_'+oe.id).addClass(oe.category);
                    
                        currentloadedlist[activeloadedlist].total += moneyamount(oe.amount); 
                        if(typeof $('#outlay_'+oe.id).prev().attr('class') !== 'undefined' && oe.created.split(' ')[0] != $('#outlay_'+oe.id).prev().attr('class').split(' ')[0] ){
                            $('#outlay_'+oe.id).addClass('changeofday');
                            $('#outlay_'+oe.id).children().eq(0).after('<span class="theday">'+oe.created.split(' ')[0]+'</span>');
                        }
                });   
                $('#messagebox').removeClass('active');
                currentloadedlist[activeloadedlist].list = $('#spending').html();
            }
            
            $('#spendingsugg').removeClass('active');
            $('#spending').addClass('active');
            
            $('#total').html(moneyformat(currentloadedlist[activeloadedlist].total,true));
            adjustbread();
            
            loadingmessagebox();
        });
        
        return;
    }
    else{
        if(activeloadedlist != 0)
            currentloadedlist[activeloadedlist].list = $('#spending').html();
        
        activeloadedlist = currentloadedlist.length;
        currentloadedlist[activeloadedlist] = [];
        currentloadedlist[activeloadedlist].total = 0;
        currentloadedlist[activeloadedlist].list = '';
        currentloadedlist[activeloadedlist].filtertype = filtertype;
        currentloadedlist[activeloadedlist].filtervalue = '~'+filtervalue;
        
        
        $('#spending').html('');
        
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'suggest',a:'spendsuggestion',d:{keyword:currentloadedlist[activeloadedlist].filtervalue,offset:0}}
        }).done(function(msg){
            msg = JSON.parse(msg);
            
            if(!msg.result.length){
                var boxtitle = 'Notice';
                var boxcontent = '<div class="row bottomless singleinput" style="text-align:center">Not much in the database with the given information</div>';
                var boxaction = '';
                
                confirmbox = new messagebox();
                confirmbox.displayfunc(boxtitle,boxcontent,boxaction);
            }
            else{
                msg.result.sort(function(a,v){
                    var cre = a.created.split(' ');
                    var ddate = cre[0].split('-');
                    var dtime = cre[1].split(':');
                    ddate = new Date(parseInt(ddate[0]),(parseInt(ddate[1])-1),parseInt(ddate[2]),dtime[0],dtime[1],dtime[2]);
                    
                    cre = v.created.split(' ');
                    var ddate_ = cre[0].split('-');
                    var dtime_ = cre[1].split(':');
                    ddate_ = new Date(parseInt(ddate_[0]),(parseInt(ddate_[1])-1),parseInt(ddate_[2]),dtime_[0],dtime_[1],dtime_[2]);
                    
                    return ddate_ - ddate;
                });
                    
                currentloadedlist[activeloadedlist].startscons = msg.startscons;
                    
                $.each(msg.result,function(oi,oe){
                    if(oi === 0){
                        firstoflatest = oe.id;
                    }
                    $('#spending').append('<li id="outlay_'+oe.id+'"><span class="title">'+oe.title+'</span><span class="amount">'+oe.amount+'</span></li>');
                    $('#outlay_'+oe.id).addClass(oe.created.split(' ')[0]);
                    $('#outlay_'+oe.id).addClass(oe.category);
                    
                        currentloadedlist[activeloadedlist].total += moneyamount(oe.amount); 
                        if(typeof $('#outlay_'+oe.id).prev().attr('class') !== 'undefined' && oe.created.split(' ')[0] != $('#outlay_'+oe.id).prev().attr('class').split(' ')[0] ){
                            $('#outlay_'+oe.id).addClass('changeofday');
                            $('#outlay_'+oe.id).children().eq(0).after('<span class="theday">'+oe.created.split(' ')[0]+'</span>');
                        }
                });   
                $('#messagebox').removeClass('active');
            }
        
            currentloadedlist[activeloadedlist].list = $('#spending').html();
            $('#spendingsugg').removeClass('active');
            $('#spending').addClass('active');
            
            $('#total').html(moneyformat(currentloadedlist[activeloadedlist].total,true));
            adjustbread();
            loadingmessagebox();
        });
    }
}
function searchbudgetfn(){
    var boxtitle = 'Searching';
    var boxcontent = '<div class="row bottomless singleinput" style="text-align:center">Searching The Database...</div>';
    var boxaction = '';
    
    confirmbox = new messagebox();
    confirmbox.displayfunc(boxtitle,boxcontent,boxaction);
    
    loadingmessagebox();
    var filtertype  = 'keyword';
    var filtervalue = $('#searchbudgetkey').val();
    
    if(filtervalue=='keyword' || filtervalue == ''){
        $('#messagebox').removeClass('active');
        loadingmessagebox();
        return;
    }
    remfilterfn(true);
    activefilteroutlay = '~'+filtervalue;
    $('#searchbudget').addClass('hide');
    $('#resetsearch').removeClass('hide');
    $('.menuitem').eq(3).addClass('hide');
    
    var fidx = searchloadedlist('~'+filtervalue,filtertype);
    if(fidx !== false){
        activeloadedlist = fidx;
        
        $('#spending').html(currentloadedlist[activeloadedlist].list);
            
        $('#searchbudgetpage').removeClass('active');
        $('#spending').addClass('active');
        
        adjusttotal();
        adjustbread();
        $('#messagebox').removeClass('active');
        loadingmessagebox();
        return;
    }
    else{
        if(activeloadedlist != 0)
            currentloadedlist[activeloadedlist].list = $('#spending').html();
        
        activeloadedlist = currentloadedlist.length;
        currentloadedlist[activeloadedlist] = [];
        currentloadedlist[activeloadedlist].total = 0;
        currentloadedlist[activeloadedlist].list = '';
        currentloadedlist[activeloadedlist].filtertype = filtertype;
        currentloadedlist[activeloadedlist].filtervalue = '~'+filtervalue;
        
        
        $('#spending').html('');
        
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'outlay',a:'searchbudget',d:{keyword:currentloadedlist[activeloadedlist].filtervalue,offset:0}}
        }).done(function(msg){
            msg = JSON.parse(msg);
            
            $.each(msg.result,function(oi,oe){
                if(oi === 0){
                    firstoflatest = oe.id;
                }
                $('#spending').append('<li id="outlay_'+oe.id+'"><span class="title">'+oe.title+'</span><span class="amount">'+oe.amount+'</span></li>');
                $('#outlay_'+oe.id).addClass(oe.created.split(' ')[0]);
                $('#outlay_'+oe.id).addClass(oe.category);
                
                    currentloadedlist[activeloadedlist].total += moneyamount(oe.amount); 
                    if(typeof $('#outlay_'+oe.id).prev().attr('class') !== 'undefined' && oe.created.split(' ')[0] != $('#outlay_'+oe.id).prev().attr('class').split(' ')[0] ){
                        $('#outlay_'+oe.id).addClass('changeofday');
                        $('#outlay_'+oe.id).children().eq(0).after('<span class="theday">'+oe.created.split(' ')[0]+'</span>');
                    }
            });
            currentloadedlist[activeloadedlist].list = $('#spending').html();
            $('#searchbudgetpage').removeClass('active');
            $('#spending').addClass('active');
            
            $('#total').html(moneyformat(currentloadedlist[activeloadedlist].total,true));
            adjustbread();
            $('#messagebox').removeClass('active');
            loadingmessagebox();
        });
    }
}
function searchoutlayfn(){
    var boxtitle = 'Searching';
    var boxcontent = '<div class="row bottomless singleinput" style="text-align:center">Searching The Database...</div>';
    var boxaction = '';
    
    confirmbox = new messagebox();
    confirmbox.displayfunc(boxtitle,boxcontent,boxaction);
    
    loadingmessagebox();
    var filtertype  = 'keyword';
    var filtervalue = $('#searchoutlaykey').val();
    
    if(filtervalue=='keyword' || filtervalue == ''){
        $('#messagebox').removeClass('active');
        loadingmessagebox();
        return;
    }
    remfilterfn(true);
    activefilteroutlay = '#'+filtervalue;
    $('#searchmenu').addClass('hide');
    $('#resetsearch').removeClass('hide');
    $('.menuitem').eq(3).addClass('hide');
    
    var fidx = searchloadedlist('#'+filtervalue,filtertype);
    if(fidx !== false){
        activeloadedlist = fidx;
        
        $('#spending').html(currentloadedlist[activeloadedlist].list);
            
        $('#searchoutlay').removeClass('active');
        $('#spending').addClass('active');
        
        adjusttotal();
        adjustbread();
        $('#messagebox').removeClass('active');
        loadingmessagebox();
        return;
    }
    else{
        if(activeloadedlist != 0)
            currentloadedlist[activeloadedlist].list = $('#spending').html();
        
        activeloadedlist = currentloadedlist.length;
        currentloadedlist[activeloadedlist] = [];
        currentloadedlist[activeloadedlist].total = 0;
        currentloadedlist[activeloadedlist].list = '';
        currentloadedlist[activeloadedlist].filtertype = filtertype;
        currentloadedlist[activeloadedlist].filtervalue = '#'+filtervalue;
        
        
        $('#spending').html('');
        
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'outlay',a:'searchoutlay',d:{keyword:currentloadedlist[activeloadedlist].filtervalue,offset:0}}
        }).done(function(msg){
            msg = JSON.parse(msg);
            
            $.each(msg.result,function(oi,oe){
                if(oi === 0){
                    firstoflatest = oe.id;
                }
                $('#spending').append('<li id="outlay_'+oe.id+'"><span class="title">'+oe.title+'</span><span class="amount">'+oe.amount+'</span></li>');
                $('#outlay_'+oe.id).addClass(oe.created.split(' ')[0]);
                $('#outlay_'+oe.id).addClass(oe.category);
                
                    currentloadedlist[activeloadedlist].total += moneyamount(oe.amount); 
                    if(typeof $('#outlay_'+oe.id).prev().attr('class') !== 'undefined' && oe.created.split(' ')[0] != $('#outlay_'+oe.id).prev().attr('class').split(' ')[0] ){
                        $('#outlay_'+oe.id).addClass('changeofday');
                        $('#outlay_'+oe.id).children().eq(0).after('<span class="theday">'+oe.created.split(' ')[0]+'</span>');
                    }
            });
            currentloadedlist[activeloadedlist].list = $('#spending').html();
            $('#searchoutlay').removeClass('active');
            $('#spending').addClass('active');
            
            $('#total').html(moneyformat(currentloadedlist[activeloadedlist].total,true));
            adjustbread();
            $('#messagebox').removeClass('active');
            loadingmessagebox();
        });
    }
}
function filteroutlay(){
    $('#menu').children().eq(4).removeClass('hide');
    var filtertype  = '';
    var filtervalue = '';
    
    filtertype  = currentloadedlist[activeloadedlist].filtertype.indexOf('day') !== -1 ? 'dayandcat' : 'cat';
    filtervalue = filtertype === 'dayandcat' ? currentloadedlist[activeloadedlist].filtervalue.split(' ')[0]+ ' '+ categoryid : categoryid;
    
    var fidx = searchloadedlist(filtervalue,filtertype);
    if(fidx !== false){
        activeloadedlist = fidx;
        
        $('#spending').html(currentloadedlist[activeloadedlist].list);
        
            
        $('#outlaycat').removeClass('active');
        $('#spending').addClass('active');
        
        adjusttotal();
        adjustbread();
        return;
    }
    else{
        if(activeloadedlist != 0)
            currentloadedlist[activeloadedlist].list = $('#spending').html();
        
        activeloadedlist = 0;
        $('#spending').html(currentloadedlist[activeloadedlist].list);
        
        activeloadedlist = currentloadedlist.length;
        currentloadedlist[activeloadedlist] = [];
        currentloadedlist[activeloadedlist].total = 0;
        currentloadedlist[activeloadedlist].list = $('#spending').html();
        currentloadedlist[activeloadedlist].filtertype = filtertype;
        currentloadedlist[activeloadedlist].filtervalue = filtervalue;
    }
    
    $('#outlaycat').removeClass('active');
    $('#spending').addClass('active');
    
    activefilteroutlay = categoryid;
    filteredtotal = 0;
    var daytoremember = '';
    var skip = false;
    $.each($('#spending').children(),function(im,em){
        if($(em).attr('class').indexOf('hide') === -1 || $(em).attr('class').indexOf('active') !== -1 ){
            if($(em).attr('class').split(' ')[1] != categoryid){
                $(em).addClass('hide').removeClass('active');
            }
            else{
                if(currentloadedlist[activeloadedlist].filtertype.indexOf('day') !== -1){
                    if($(em).attr('class').split(' ')[0] != currentloadedlist[activeloadedlist].filtervalue.split(' ')[0]){
                        skip = true;
                        $(em).addClass('hide').removeClass('active');
                    }
                    else{
                        skip = false;
                    }
                }
                else{
                    skip = false;
                }
                
                if(!skip){
                    if($(em).attr('class').split(' ')[0] != daytoremember){
                        daytoremember = $(em).attr('class').split(' ')[0];
                        if(!$(em).children('.theday').length){
                            $(em).children('.title').after('<span class="theday">'+daytoremember+'</span>');
                            $(em).addClass('changeofday');
                            if(currentloadedlist[activeloadedlist].filtertype.indexOf('day') !== -1 && daytoremember == currentloadedlist[activeloadedlist].filtervalue.split(' ')[0]){
                                $(em).children('.theday').addClass('focused');
                            }
                        }
                        else{
                            if(currentloadedlist[activeloadedlist].filtertype.indexOf('day') === -1){
                                $(em).children('.theday').removeClass('focused');
                            }
                            else{
                                $(em).children('.theday').addClass('focused');
                            }
                        }
                    }
                    filteredtotal += moneyamount($(em).children('.amount').html());
                }
            }   
        }
    });
    currentloadedlist[activeloadedlist].total = filteredtotal;
    $('#total').html(moneyformat(filteredtotal,true));
    adjustbread();
}
function newoutlaybox(categoryname){
    var boxtitle = 'New Outlay - '+categoryname;
    var boxcontent = '<div class="row bottomless singleinput"><input type="text" value="Item Name" name="Item Name" class="otitle"></div>'
    +'<div class="row bottomless singleinput"><input type="text" value="Amount" name="Amount" class="oamount"></div>'
    +'<div class="row bottomless singleinput"><div name="Description" style="height:150px" class="odesc" id="odesc_'+odesccounter()+'"></div></div>';
    var boxaction = '<span id="confirmnewoutlay">Confirm</span>';
    
    confirmbox = new messagebox();
    confirmbox.displayfunc(boxtitle,boxcontent,boxaction); 
    tinythentinynow(prevodesccount());
}
function moneyamount(htmltext){
    var theamount = '';
    for(var i=0;i<htmltext.length;i++){
        if(htmltext[i] !=','){
            theamount += htmltext[i];
        }
    }
    return parseInt(theamount);
}
function sendnewoutlay(title,amount,desc,mode){
    if(mode.indexOf('New Outlay') !== -1){
        loadingmessagebox();
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'outlay',a:'addnew',d:{title:title,amount:amount,content:desc,status:1,category:categoryid}}
        }).done(function(msg){
            msg = JSON.parse(msg);
            if(msg.result ==false){
                errorbox(msg);
                return;
            }
            
            $('#spending').html(currentloadedlist[0].list);
            activeloadedlist = 0;
            
            if($('#spending').children().length){
                if($('#spending').children().eq(0).attr('class').split(' ')[0] == msg.created){
                    $('#spending').children().eq(0).removeClass('changeofday');
                    $('#spending').children().eq(0).children('.theday').remove();
                }
                $('#spending').children().eq(0).before('<li id="outlay_'+msg.result+'" class="'+msg.created+' '+categoryid+' changeofday"><span class="title">'+title+'</span><span class="theday">'+msg.created+'</span><span class="amount">'+msg.amount+'</span></li>');
            }
            else{
                $('#spending').append('<li id="outlay_'+msg.result+'" class="'+msg.created+' '+categoryid+' changeofday"><span class="title">'+title+'</span><span class="theday">'+msg.created+'</span><span class="amount">'+msg.amount+'</span></li>');
            }
            
            currentloadedlist[0].list = $('#spending').html();
            
            confirmbox.close();
            $('#outlaycat').removeClass('active');
            $('#spending').addClass('active');
            
            
            totalbudget -= parseInt(amount);
            $('#thebudget').html(moneyformat(totalbudget,true));
            adjustbgbybudget();
            
            total += parseInt(amount);
            $('#total').html(moneyformat(total,true));
            loadingmessagebox();
        });        
    }
    else if(mode.indexOf('Confirm Wish') !== -1){
        amount = moneyamount(amount);
        loadingmessagebox();
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'outlay',a:'confirmwish',d:{wishid:focusedwish,title:title,amount:amount,content:desc}}
        }).done(function(msg){
            msg = JSON.parse(msg);
            if(msg.result ==false){
                errorbox(msg);
                return;
            }
                total       += parseInt(amount);
                totalbudget -= parseInt(amount);
                
                $('#thebudget').html(moneyformat(totalbudget,true));
                adjustbgbybudget();
                
                if($('#spending').children().length){
                    if($('#spending').children().eq(0).attr('class').split(' ')[0] == msg.created){
                        $('#spending').children().eq(0).removeClass('changeofday');
                        $('#spending').children().eq(0).children('.theday').remove();
                    }
                    $('#spending').children().eq(0).before('<li id="outlay_'+focusedwish+'" class="'+msg.created+' changeofday"><span class="title">'+title+'</span><span class="theday">'+msg.created+'</span><span class="amount">'+moneyformat(amount,false)+'</span></li>');    
                }
                else{
                    $('#spending').append('<li id="outlay_'+focusedwish+'" class="'+msg.created+' changeofday"><span class="title">'+title+'</span><span class="theday">'+msg.created+'</span><span class="amount">'+moneyformat(amount,false)+'</span></li>');
                }
                
                currentloadedlist[0].list = $('#spending').html();
                
                confirmbox.close();
                
                $('#wish_'+focusedwish).remove();
                $('#total').html(moneyformat(total,true));
                adjusttotal();
                adjustbread();
                loadingmessagebox();
                updatewishorder();
        });    
    }
    else if(mode.indexOf('New Wish') !== -1){
        loadingmessagebox();
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'outlay',a:'newwish',d:{title:title,amount:amount,content:desc,status:1,category:categoryid}}
        }).done(function(msg){
            msg = JSON.parse(msg);
            if(msg.result ==false){
                errorbox(msg);
                return;
            }
            if($('#wishlist').children().length){
                $('#wishlist').children().eq(0).before('<li id="wish_'+msg.result+'"><span class="title">'+title+'</span><span class="amount">'+moneyformat(amount,false)+'</span></li>');   
            }
            else{
                $('#wishlist').append('<li id="wish_'+msg.result+'"><span class="title">'+title+'</span><span class="amount">'+moneyformat(amount,false)+'</span></li>');
            }
            confirmbox.close();
            $('#outlaycat').removeClass('active');
            $('#wishlist').addClass('active');
            adjusttotal();
            adjustbread();
            loadingmessagebox();
            updatewishorder();
        });  
    }
    else if(mode.indexOf('Add Budget') !== -1){
        loadingmessagebox();
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'outlay',a:'addbudget',d:{title:title,amount:amount,content:desc,status:1}}
        }).done(function(msg){
            msg = JSON.parse(msg);
            if(msg.result ==false){
                errorbox(msg);
                return;
            }
            totalbudget += parseInt(amount);
            $('#thebudget').html(moneyformat(totalbudget,true));
            adjustbgbybudget();
            
            
            if($('#budgetlist').children().length){
                if($('#budgetlist').children().eq(0).attr('class').split(' ')[0] == msg.created){
                    $('#budgetlist').children().eq(0).removeClass('changeofday');
                    $('#budgetlist').children().eq(0).children('.theday').remove();
                }
                $('#budgetlist').children().eq(0).before('<li id="budget_'+msg.result+'" class="'+msg.created+' changeofday"><span class="title">'+title+'</span><span class="theday">'+msg.created+'</span><span class="amount">'+moneyformat(amount,false)+'</span></li>');   
            }
            else{
                $('#budgetlist').append('<li id="budget_'+msg.result+'"><span class="title">'+title+'</span><span class="amount">'+moneyformat(amount,false)+'</span></li>');
            }
            confirmbox.close();
            adjusttotal();
            loadingmessagebox();
        });  
    }
    else if(mode.indexOf('Save Report') !== -1){
        var repitems = [];
        $.each($('#report').children(),function(ri,re){
            repitems[repitems.length] = $(re).attr('id').substr(7);
        });
        loadingmessagebox();
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'outlay',a:'savereport',d:{id:thereportvar.id,title:title,amount:amount,content:desc,status:1,items:repitems.join(',')}}
        }).done(function(msg){
            msg = JSON.parse(msg);
            $('#report').removeClass('active');
            
            if(thereportvar.id === false){
                if($('#pastreports').children().length){
                    $('#pastreports').children().eq(0).before('<li id="pastreports_'+msg.result+'" class="'+msg.created+'"><span class="title">'+title+'</span><span class="amount">'+moneyformat(amount,false)+'</span></li>');
                }
                else{
                    $('#pastreports').append('<li id="pastreports_'+msg.result+'" class="'+msg.created+'"><span class="title">'+title+'</span><span class="theday">'+msg.created+'</span><span class="amount">'+moneyformat(amount,false)+'</span></li>');
                }
            }
            else{
                $('#pastreports_'+thereportvar.id).remove();
                
                if($('#pastreports').children().length){
                    $('#pastreports').children().eq(0).before('<li id="pastreports_'+msg.result+'" class="'+msg.created+'"><span class="title">'+title+'</span><span class="amount">'+moneyformat(amount,false)+'</span></li>');
                }
                else{
                    $('#pastreports').append('<li id="pastreports_'+msg.result+'" class="'+msg.created+'"><span class="title">'+title+'</span><span class="theday">'+msg.created+'</span><span class="amount">'+moneyformat(amount,false)+'</span></li>');
                }   
            }
            
            $('#report').removeClass('active');
            $('#pastreports').addClass('active');
            confirmbox.close();
            
            adjusttotal();
            adjustbread();
            thereportvar.title = 'Report Title';
            thereportvar.desc = 'Report Description';
            thereportvar.id = false;
            loadingmessagebox();
        });  
    }
}
function errorbox(msg){
    var boxtitle = 'error occured';
    var boxcontent = '';
    $.each(msg,function(mi,me){
        boxcontent+= mi+' : '+me;;
    });
    
    confirmbox = new messagebox();
    confirmbox.displayfunc(boxtitle,boxcontent,'');
    loadingmessagebox();
}
function adjustbread(){
    switch($('.list.active').attr('id')){
        case 'wishlist':
            $('#breadcrumbscontent').removeClass('savereport');
            $('#breadcrumbscontent').html(moneyformat(totalbudget-totalwish,true));
            adjustbgbybudget();
        break;
        case 'spending':
            $('#breadcrumbscontent').removeClass('savereport');
            if(activeloadedlist !== 0){
                var bread = currentloadedlist[activeloadedlist].filtervalue.split(' ');
                
                if(bread.length > 1 && bread[1].indexOf('^') !== -1){
                    $('#breadcrumbscontent').html(bread.join(' '));
                }
                else{
                    if(bread.length > 1 && bread[1].indexOf('~') === -1 && bread[1].indexOf('#') === -1){
                        $('#breadcrumbscontent').html(bread[0]+' '+$('#searchcat_'+bread[1]).children().html());
                    }
                    else{
                        if(bread[0].indexOf('-') !== -1 || bread[0].indexOf('#') !== -1)
                            $('#breadcrumbscontent').html(bread.join(' '));
                        else if(bread[0].indexOf('-') !== -1 || bread[0].indexOf('~') !== -1){
                            $('#breadcrumbscontent').html(bread.join(' '));
                        }
                        else{
                            $('#breadcrumbscontent').html($('#searchcat_'+bread[0]).children().html());
                        }
                    }   
                }
            }
            else{
                $('#breadcrumbscontent').html('');
            }
            
            if(markedpos !== false){
                if($('#spending').children('.'+markedpos).length){
                    $('#spending').children('.'+markedpos).eq(0)[0].scrollIntoView();
                }
                markedpos = false;
            }
        break;
        case 'report':
            if($('#report').children().length){
                $('#breadcrumbscontent').html('save report').addClass('savereport');    
            }
            else{
                $('#breadcrumbscontent').html('').removeClass('savereport');    
            }
        break;
        case 'pastreports':
            $('#breadcrumbscontent').html('').removeClass('savereport');
        break;
        case 'currentreport':
            $('#breadcrumbscontent').html(thereportvar.title).removeClass('savereport');
        break;
    }
}
function adjusttotal(){
    switch($('.list.active').attr('id')){
        case 'currentreport':
            thereportvar.total = 0;
            $.each($('#currentreport').children(),function(ri,re){
               thereportvar.total += moneyamount($(re).children('.amount').html()); 
            });
            $('#total').html(moneyformat(thereportvar.total,true));            
        break;
        case 'pastreports':
            var totalreport = 0;
            $('#total').html(moneyformat(totalreport,false));            
        break;
        case 'report':
            var totalreport = 0;
            $.each($('#report').children(),function(wi,we){
                totalreport +=  moneyamount($(we).children('.amount').html());
            });
            $('#total').html(moneyformat(totalreport,true));            
        break;
        case 'wishlist':
            totalwish = 0;
            $.each($('#wishlist').children(),function(wi,we){
                if($(we).children('.amount').attr('class').indexOf('skip')===-1)
                    totalwish +=  moneyamount($(we).children('.amount').html());
            });
            $('#total').html(moneyformat(totalwish,true));
            adjustbgbybudget();
        break;
        case 'budgetlist':
            var totalbudgettemp = 0;
            $.each($('#budgetlist').children(),function(wi,we){
                totalbudgettemp +=  moneyamount($(we).children('.amount').html());
            });
            $('#total').html(moneyformat(totalbudgettemp,true));
        break;
        case 'spending':
            $('#total').html(moneyformat(currentloadedlist[activeloadedlist].total,true));
        break;
        case 'menu':
        case 'outlaycat':
        break;
    }
}
function registaforminput(containerid,inputtypes){
    if(containerid === 'body'){
        containerid = 'body';
    }
    else{
        containerid = '#'+containerid;
    }
     $(containerid).delegate(inputtypes,'click focus',function(event){
        event.stopPropagation();
        if(typeof($(this).attr('class')) !== 'undefined' && $(this).attr('class').indexOf('filled') !== -1){
            return;
        }
        if(typeof($(this).attr('name')) !== 'undefined') {
            var formarray = $(this).attr('name').indexOf('[');
            if(formarray == -1){
                formarray = ($(this).attr('name').length);
            }
            
            if($(this).attr('name').indexOf('password') !== -1 ){
               $(this).prop('type','password'); 
            }
            
            if ($(this).val() === $(this).attr('name').substr(0,formarray)) {
                $(this).val('');
            }
        }
    });
    $(containerid).delegate(inputtypes,'blur',function(event){
        if(typeof($(this).attr('name')) !== 'undefined') {
            var formarray = $(this).attr('name').indexOf('[');
            if(formarray == -1){
                formarray = ($(this).attr('name').length);
            }
            if ($(this).val() === '') {
                if($(this).attr('name').indexOf('password') !== -1 ){
                    $(this).prop('type','text'); 
                 }
                $(this).val($(this).attr('name').substr(0,formarray));
                $(this).removeClass('filled');
            }
            else{
                if($(this).val() != $(this).attr('name').substr(0,formarray))
                    $(this).addClass('filled');
                else{
                    $(this).removeClass('filled');
                }
            }   
        }
    });
}
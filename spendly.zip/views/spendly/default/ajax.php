<?php
if(isset($pagevar['response']))
    echo json_encode($pagevar['response']);

?>
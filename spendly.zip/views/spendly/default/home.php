<div id="logo">
    <div id="logopart" class="table">
        <div class="tablecell">
            <span id="logotext">Spendly</span>
            <span id="total">1000</span>
        </div>
    </div>
    <span id="breadcrumbs"><div class="table"><div id="breadcrumbscontent" class="tablecell"></div></div></span>
</div>

<ul id="menu"  class="list">
    <li class="menuitem">New Outlay</li>
    <li class="menuitem">Wishlist</li>
    <li class="menuitem">New Wish</li>
    <li class="menuitem">Filter Outlay</li>
    <li class="menuitem hide" id="removefiltermenu">Remove Filter</li>
    <li class="menuitem" id="searchmenu">Search</li>
    <li class="menuitem" id="searchbudget">Search Budget</li>
    <li class="menuitem hide" id="resetsearch">Reset Search</li>
    <li class="menuitem" id="loadolderoutlaymenu">Load Older Outlay</li>
    <li class="menuitem right">Report</li>
    <li class="menuitem right hide">Reset Report</li>
    <li class="menuitem right">Past Reports</li>
    <li class="menuitem right">Generate Time Based Report</li>
    <li class="menuitem right">Budget Summary</li>
    <li class="menuitem right">Load Older Budget</li>
    <li class="menuitem right">Add Budget</li>
    <li class="menuitem right" id="spendsugg">Spending Suggestions</li>
    <li class="menuitem right hide" id="resetsugg">Reset Suggestions</li>
    <li class="menuitem right">Exit</li>
    <li id="thebudget"><?php echo $pagevar['budgettotal']; ?></li>
</ul>


<ul id="currentreport" class="list"></ul>
<ul id="report" class="list"></ul>

<ul id="pastreports" class="list">
    <?php 
        $theday     = date('Y-m-d',time()); 
        $aday       = 86400;
    ?>
    
    <?php foreach($pagevar['pastreports'] as $k=>$v){ 
    
            if($k == 0 || date('Y-m-d',strtotime($v['created'])) != $theday){
                $theday = date('Y-m-d',strtotime($v['created']));
                $class= $theday.' changeofday';
            }
            else $class=$theday;
    
    ?>
        <li id="pastreports_<?php echo $v['id']; ?>" class="<?php echo $class; ?>">
            <span class="title"><?php echo $v['title']; ?></span>
            <span class="amount"><?php echo number_format($v['amount']); ?></span>
        </li>
    <?php } ?>
</ul>

<ul id="wishlist" class="list">
    <?php foreach($pagevar['wishlist'] as $k=>$v){ ?>
        <li id="wish_<?php echo $v['id']; ?>" class="order_<?php echo $v['order']; ?>">
            <span class="title"><?php echo $v['title']; ?></span>
            <span class="amount"><?php echo number_format($v['amount']); ?></span>
        </li>
    <?php } ?>
</ul>

<ul id="budgetlist" class="list">
    <?php 
        $theday     = date('Y-m-d',time()); 
        $aday       = 86400;
    ?>
    <?php foreach($pagevar['budgetlist'] as $k=>$v){ ?>
        <?php 
            if($k == 0 || date('Y-m-d',strtotime($v['created'])) != $theday){
                $theday = date('Y-m-d',strtotime($v['created']));
                $class= $theday.' changeofday';
            }
            else $class=$theday.' ';
        ?>
        
        
        <li id="budget_<?php echo $v['id']; ?>" class="<?php echo $class; ?>">
            <span class="title"><?php echo $v['title']; ?></span>
            
            <?php
                if($k==0 || date('Y-m-d',strtotime($pagevar['budgetlist'][$k-1]['created'])) != date('Y-m-d',strtotime($v['created'])) ){
                    ?>
                    
                    <span class="theday"><?php echo date('Y-m-d',strtotime($v['created'])); ?></span>
                    
                    <?php
                }
            ?>
            
            <span class="amount"><?php echo number_format($v['amount']); ?></span>
        </li>
    <?php } ?>
</ul>
<div id="spendingsugg" class="list">
    <div class="table">
        <div class="tablecell">
            <div class="row"><input type="text" name="budget" value="budget" id="sugg_budget"></div>
            <div class="row"><input type="text" name="duration in day" value="duration in day" id="sugg_duration"></div>
            <div class="row"><span class="submitbtn" id="gosuggest">Suggest Spending</span></div>
        </div>
    </div>
</div>
<div id="searchbudgetpage" class="list">
    <div class="table">
        <div class="tablecell">
            <div class="row"><input type="text" name="keywords separated by ~" value="keywords separated by ~" id="searchbudgetkey"></div>
            <div class="row"><span class="submitbtn" id="gosearchbudget">Search</span></div>
        </div>
    </div>
</div>
<div id="searchoutlay" class="list">
    <div class="table">
        <div class="tablecell">
            <div class="row"><input type="text" name="keywords separated by #" value="keywords separated by #" id="searchoutlaykey"></div>
            <div class="row"><span class="submitbtn" id="gosearchoutlay">Search</span></div>
        </div>
    </div>
</div>
<ul id="outlaycat" class="list">
    <?php echo $velp->blogcathierarchylist('searchcat',$pagevar['categories'],array(8,9,10,11,14));  ?>
</ul>

<ul id="spending" class="list active">
    <?php 
        $theday     = date('Y-m-d',time()); 
        $aday       = 86400;
    ?>
    <?php foreach($pagevar['latestspending'] as $k=>$v){ ?>
        <?php 
            if($k == 0 || date('Y-m-d',strtotime($v['created'])) != $theday){
                $theday = date('Y-m-d',strtotime($v['created']));
                $class= $theday.' '.$v['category'].' changeofday';
            }
            else $class=$theday.' '.$v['category'];
        ?>
    
        <li id="outlay_<?php echo $v['id']; ?>" class="<?php echo $class; ?>">
            <span class="title"><?php echo $v['title']; ?></span>
            <?php
                if($k==0 || date('Y-m-d',strtotime($pagevar['latestspending'][$k-1]['created'])) != date('Y-m-d',strtotime($v['created'])) ){
                    ?>
                    
                    <span class="theday"><?php echo date('Y-m-d',strtotime($v['created'])); ?></span>
                    
                    <?php
                }
            ?>
            <span class="amount"><?php echo number_format($v['amount']); ?></span>
        </li>
    <?php } ?>
</ul>

<script type="text/javascript">
var ismobile = <?php echo $pagevar['ismobile']; ?>;
</script>
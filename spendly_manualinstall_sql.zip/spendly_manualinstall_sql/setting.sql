-- phpMyAdmin SQL Dump
-- version 4.4.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 24, 2018 at 05:19 PM
-- Server version: 10.2.9-MariaDB-10.2.9+maria~xenial-log
-- PHP Version: 7.0.32-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pxpedia`
--

--
-- Dumping data for table `setting`
--

INSERT INTO `setting` (`id`, `type`, `app`, `name`, `value`) VALUES
(53, 'globalpage', 47, 'dbsetting', '{"dbhost":"localhost","dbuser":"root","dbpasswd":"catormouse","dbname":"spendly"}'),
(54, 'globalpage', 47, 'headsrc', '{"spendly_fontface":"spendly\\/default\\/styles\\/fontface.css","spendly_style":"spendly\\/default\\/styles\\/style.css","nownews_spendlydatepicker":"nownews\\/default\\/styles\\/blitzer\\/spendlydatepicker.css"}'),
(55, 'globalpage', 47, 'footsrc', '{"jquery_jquery-191minjs":"jquery\\/jquery-1.9.1.min.js","jquery_jquery-ui-1103customminjs":"jquery\\/jquery-ui-1.10.3.custom.min.js","spendly_spendlyjs":"spendly\\/spendly.js","msgbox_msgboxjs":"msgbox\\/msgbox.js","tinymce_tinymceminjs":"tinymce\\/js\\/tinymce\\/tinymce.min.js"}'),
(56, 'globalpage', 47, 'keywords', 'keywords');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
